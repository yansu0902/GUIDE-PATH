"""Load the raw corpus into dense learner x step arrays and build training batches."""
import os
import numpy as np
import pandas as pd
from simulator import K, P, load_curriculum, PREREQ, SKILL_DOMAIN

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WINDOW = 30           # horizon (steps) for the delayed learning outcome used by SEH


class Corpus:
    def __init__(self, root=ROOT):
        raw = os.path.join(root, "data", "raw")
        self.cur = load_curriculum(os.path.join(root, "data", "ground_truth", "curriculum.npz"))
        df = pd.read_csv(os.path.join(raw, "interactions.csv")).sort_values(["learner_id", "step"])
        lr = pd.read_csv(os.path.join(raw, "learners.csv"))
        self.N = lr.shape[0]
        self.T = int(df.step.max() + 1)
        sh = (self.N, self.T)
        self.items = df.item_id.values.reshape(sh)
        self.strat = df.strategy_id.values.reshape(sh)
        self.resp = df.correct.values.reshape(sh).astype(np.float32)
        self.time = df.timestamp_h.values.reshape(sh).astype(np.float32)
        self.minutes = df.study_minutes.values.reshape(sh).astype(np.float32)
        self.prop = df.logging_propensity.values.reshape(sh).astype(np.float32)
        self.split = {s: lr.learner_id.values[lr.split.values == s] for s in ["train", "valid", "test"]}
        self.Qn = self.cur.Qn.astype(np.float32)
        self._delayed()
        # self-normalised inverse-propensity weights towards the uniform strategy policy
        self.ipw = np.clip((1.0 / P) / self.prop, 0.2, 5.0).astype(np.float32)

    def _delayed(self):
        Q = self.cur.Q
        yg = np.zeros((self.N, self.T), np.float32)
        mg = np.zeros((self.N, self.T), np.float32)
        nx = np.zeros((self.N, self.T), int)
        ndt = np.zeros((self.N, self.T), np.float32)
        tri = np.triu(np.ones((self.T, self.T), bool), 1) & ~np.triu(np.ones((self.T, self.T), bool), WINDOW + 1)
        for u in range(self.N):
            Qu = Q[self.items[u]]
            ov = (Qu @ Qu.T > 0) & tri
            has = ov.any(1)
            nxt = ov.argmax(1)
            yg[u, has] = self.resp[u, nxt[has]]
            mg[u, has] = 1.0
            nx[u] = np.where(has, self.items[u, nxt], self.items[u])
            ndt[u] = np.where(has, self.time[u, nxt] - self.time[u], 24.0)
        self.yg, self.mg = yg, mg
        self.next_item, self.next_dt = nx, np.log1p(np.maximum(ndt, 0)).astype(np.float32)

    def batch(self, ids, ipw=True):
        it = self.items[ids]
        tm = self.time[ids]
        Mn = self.Qn[it]                                             # B,T,K
        prev_t = np.concatenate([tm[:, :1], tm[:, :-1]], 1)           # time of key j-1
        D = tm[:, :, None] - prev_t[:, None, :]                       # B,T,T  (t, j)
        Tn = self.T
        allow = np.tril(np.ones((Tn, Tn), bool))                      # key j <= t (j=0 is start token)
        D = np.where(allow[None], np.maximum(D, 0), 0.0)
        D[:, :, 0] = 0.0
        pos = np.arange(Tn)
        Pd = np.where(allow, pos[:, None] - pos[None, :] + 1, 0).astype(np.float32)
        Pd[:, 0] = 0
        return dict(items=it, Mn=Mn, s=self.strat[ids], r=self.resp[ids], time=tm,
                    Dlog=np.log1p(D).astype(np.float32)[:, None], Plog=np.log1p(Pd)[None, None],
                    mask_add=np.where(allow, 0.0, -1e9).astype(np.float32)[None, None],
                    m=np.ones_like(self.resp[ids]), yg=self.yg[ids], mg=self.mg[ids],
                    nx=self.next_item[ids], Mn_nx=self.Qn[self.next_item[ids]], ndt=self.next_dt[ids],
                    w=(self.ipw[ids] if ipw else np.ones_like(self.ipw[ids])))


def skill_graph():
    """Edge-type matrix for the heterogeneous skill graph.
    type[i, j]: relation of source j -> target i : 0 none, 1 self, 2 prerequisite (j is prereq of i),
    3 dependent (j depends on i), 4 same-domain peer."""
    E = np.zeros((K, K), int)
    same = SKILL_DOMAIN[:, None] == SKILL_DOMAIN[None, :]
    E[same] = 4
    E[PREREQ.T > 0] = 2
    E[PREREQ > 0] = 3
    np.fill_diagonal(E, 1)
    return E
