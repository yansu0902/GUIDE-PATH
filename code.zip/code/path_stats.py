"""Summary table and paired significance tests for the learning-path experiments."""
import os, glob, json
import numpy as np
import pandas as pd
from scipy.stats import wilcoxon
from dataset import ROOT

R = os.path.join(ROOT, "results")


def main():
    P = {}
    for f in glob.glob(os.path.join(R, "paths", "*.csv")):
        if "_n600" in f:
            continue
        df = pd.read_csv(f).sort_values("learner"); P[df.policy.iloc[0]] = df
    ref = P["GUIDE-PATH (ZPD-LGWO)"]
    rng = np.random.default_rng(0)
    rows = []
    for name, df in P.items():
        r = dict(policy=name, n=len(df))
        for m in ["Ep", "Ep_ret", "zpd", "strat_opt", "minutes", "gain_per_hour", "n_distinct_strats", "sec_per_learner"]:
            r[m] = float(df[m].mean()); r[m + "_sd"] = float(df[m].std())
        if name != "GUIDE-PATH (ZPD-LGWO)" and (df.learner.values == ref.learner.values).all():
            for m in ["Ep", "Ep_ret", "gain_per_hour"]:
                d = ref[m].values - df[m].values
                r[f"diff_{m}"] = float(d.mean())
                r[f"p_{m}"] = float(wilcoxon(ref[m].values, df[m].values).pvalue) if np.any(d != 0) else 1.0
                bs = [rng.choice(d, len(d)).mean() for _ in range(2000)]
                r[f"ci_{m}"] = [float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))]
            r["win_rate_Ep"] = float((ref.Ep.values > df.Ep.values).mean())
        rows.append(r)
    out = pd.DataFrame(rows).sort_values("Ep", ascending=False)
    out.to_csv(os.path.join(R, "path_summary.csv"), index=False)
    json.dump(rows, open(os.path.join(R, "path_summary.json"), "w"), indent=1)
    cols = ["policy", "Ep", "Ep_ret", "zpd", "strat_opt", "minutes", "gain_per_hour", "p_Ep", "p_Ep_ret", "win_rate_Ep"]
    print(out[[c for c in cols if c in out]].to_string(index=False))


if __name__ == "__main__":
    main()
