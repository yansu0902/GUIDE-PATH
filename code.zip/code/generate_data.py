"""Generate the EngPath-Sim corpus (raw data) with the behaviour policy.

Outputs (data/raw):  skills.csv, prerequisite_edges.csv, strategies.csv, items.csv,
                     learners.csv (observable profile), interactions.csv
Outputs (data/ground_truth): hidden latent states used only for counterfactual evaluation.
"""
import os, json, sys
import numpy as np
import pandas as pd
from simulator import (Curriculum, LearnerState, Simulator, BehaviourPolicy, session_gaps,
                       SKILLS, SKILL_CODES, DOMAINS, SKILL_DOMAIN, PREREQ_EDGES, STRATEGIES,
                       SUPPORT, TIME_MULT, K, P, sig)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAW = os.path.join(ROOT, "data", "raw")
GT = os.path.join(ROOT, "data", "ground_truth")
SEED, N, T = 2026, 3000, 100


def main():
    rng = np.random.default_rng(SEED)
    cur = Curriculum(rng)
    st = LearnerState(N, rng)
    sim = Simulator(cur)
    beh = BehaviourPolicy(cur, N, rng, eps=0.5)
    gaps = session_gaps(rng, N, T)
    perm = rng.permutation(N)
    split = np.empty(N, dtype=object)
    split[perm[:2100]] = "train"; split[perm[2100:2400]] = "valid"; split[perm[2400:]] = "test"
    test_ids = np.sort(perm[2400:])

    I = np.zeros((N, T), int); S = np.zeros((N, T), int); R = np.zeros((N, T), int)
    PR = np.zeros((N, T)); PC = np.zeros((N, T)); RT = np.zeros((N, T)); CLK = np.zeros((N, T))
    SESS = np.zeros((N, T), int); MIN = np.zeros((N, T))
    th_b = np.zeros((len(test_ids), T, K), np.float32); stab_b = np.zeros_like(th_b)
    mot_b = np.zeros((len(test_ids), T), np.float32); last_b = np.zeros((len(test_ids), T, 3), np.int8)
    sess = np.zeros(N, int)
    for t in range(T):
        sim.forget(st, gaps[:, t]); st.clock += gaps[:, t]
        sess += (gaps[:, t] > 1.0)
        th_b[:, t] = st.theta[test_ids]; stab_b[:, t] = st.stab[test_ids]
        mot_b[:, t] = st.mot[test_ids]; last_b[:, t] = st.last_s[test_ids]
        items, strats, prop, _ = beh.act()
        r, p, minutes = sim.step(st, items, strats, np.zeros(N), rng)
        beh.update(items, r)
        rt = np.exp(np.log(cur.tmin[items] * 60 * 0.25) + 0.5 * (1 - p) + rng.normal(0, 0.3, N))
        I[:, t], S[:, t], R[:, t], PR[:, t], PC[:, t] = items, strats, r, prop, p
        RT[:, t], CLK[:, t], SESS[:, t], MIN[:, t] = rt, st.clock.copy(), sess, minutes

    os.makedirs(RAW, exist_ok=True); os.makedirs(GT, exist_ok=True)
    pd.DataFrame([dict(skill_id=i, code=c, name=n, domain=DOMAINS[d]) for i, (c, n, d) in enumerate(SKILLS)]
                 ).to_csv(os.path.join(RAW, "skills.csv"), index=False)
    pd.DataFrame([dict(prerequisite=a, dependent=b) for a, b in PREREQ_EDGES]
                 ).to_csv(os.path.join(RAW, "prerequisite_edges.csv"), index=False)
    pd.DataFrame([dict(strategy_id=i, code=c, name=n, immediate_support_logit=SUPPORT[i], time_multiplier=TIME_MULT[i])
                  for i, (c, n) in enumerate(STRATEGIES)]).to_csv(os.path.join(RAW, "strategies.csv"), index=False)
    pd.DataFrame(dict(item_id=np.arange(cur.n), primary_skill=[SKILL_CODES[k] for k in cur.primary],
                      skills=[";".join(SKILL_CODES[k] for k in sk) for sk in cur.skills],
                      difficulty_b=cur.b.round(4), discrimination_a=cur.a.round(4),
                      base_minutes=cur.tmin.round(3))).to_csv(os.path.join(RAW, "items.csv"), index=False)
    cefr = np.array(["A1", "A2", "B1", "B2"])[st.cefr]
    pd.DataFrame(dict(learner_id=np.arange(N), placement_cefr=cefr, split=split)
                 ).to_csv(os.path.join(RAW, "learners.csv"), index=False)
    uid = np.repeat(np.arange(N), T); stp = np.tile(np.arange(T), N)
    df = pd.DataFrame(dict(
        learner_id=uid, step=stp, session=SESS.ravel(), timestamp_h=CLK.ravel().round(4),
        item_id=I.ravel(), skills=[";".join(SKILL_CODES[k] for k in cur.skills[i]) for i in I.ravel()],
        strategy_id=S.ravel(), strategy=[STRATEGIES[s][0] for s in S.ravel()],
        correct=R.ravel(), response_time_s=RT.ravel().round(2), study_minutes=MIN.ravel().round(3),
        logging_propensity=PR.ravel().round(5)))
    df.to_csv(os.path.join(RAW, "interactions.csv"), index=False)
    # hidden ground truth (evaluation only)
    np.savez_compressed(os.path.join(GT, "test_states_before_step.npz"), learner_ids=test_ids,
                        theta=th_b, stab=stab_b, mot=mot_b, last_s=last_b, p_true=PC[test_ids].astype(np.float32))
    np.savez_compressed(os.path.join(GT, "final_states.npz"), **{k: v for k, v in st.__dict__.items()
                                                                 if isinstance(v, np.ndarray)})
    np.savez_compressed(os.path.join(GT, "curriculum.npz"), primary=cur.primary, b=cur.b, a=cur.a,
                        tmin=cur.tmin, Q=cur.Q)
    stats = dict(learners=N, steps_per_learner=T, interactions=int(N * T), items=int(cur.n), skills=K,
                 strategies=P, prereq_edges=len(PREREQ_EDGES), accuracy=float(R.mean()),
                 mean_sessions=float(SESS[:, -1].mean() + 1), span_days=float(CLK[:, -1].mean() / 24),
                 strategy_freq={STRATEGIES[p][0]: float((S == p).mean()) for p in range(P)},
                 cefr_freq={c: float((cefr == c).mean()) for c in ["A1", "A2", "B1", "B2"]},
                 mean_theta_gain=float((st.theta - st.theta0).mean()),
                 split=dict(train=2100, valid=300, test=600))
    json.dump(stats, open(os.path.join(ROOT, "results", "dataset_stats.json"), "w"), indent=2)
    print(json.dumps(stats, indent=2))


if __name__ == "__main__":
    main()
