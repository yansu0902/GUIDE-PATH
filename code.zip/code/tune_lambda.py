"""Select PATH objective weights on 30 VALIDATION learners (simulator), never on test learners."""
import os, json, itertools
import numpy as np
from dataset import Corpus, ROOT
from fast import WorldModel
from planning import Planner, Evaluator
from run_guidance import load_model

C = Corpus()
ids = np.sort(np.random.default_rng(9).choice(C.split["valid"], 30, replace=False))
theta = np.array(json.load(open(os.path.join(ROOT, "results", "epsg_theta.json")))["theta"])
wm = WorldModel(load_model(C, "GUIDE", 0), C.Qn)
ev = Evaluator(C, ids)
part = os.path.join(ROOT, "results", "path_lambda_partial.json")
out = json.load(open(part)) if os.path.exists(part) else []
done = {(r["u"], r["n"]) for r in out}
for lu, ln in itertools.product([0.01, 0.03], [0.0, 0.05, 0.15]):
    if (lu, ln) in done:
        continue
    pl = Planner(C, wm, theta, lam=dict(u=lu, n=ln))
    rows, _ = ev.run("plan", wm=wm, planner=pl, opt="lgwo")
    ep = float(np.mean([r["Ep"] for r in rows]))
    out.append(dict(u=lu, n=ln, Ep=ep, Ep_ret=float(np.mean([r["Ep_ret"] for r in rows]))))
    print(out[-1], flush=True)
    json.dump(out, open(part, "w"))
best = max(out, key=lambda r: r["Ep"])
json.dump(dict(grid=out, best=best), open(os.path.join(ROOT, "results", "path_lambda.json"), "w"), indent=1)
print("best", best)
