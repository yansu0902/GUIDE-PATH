"""Result figures (Fig. 3-9) for the GUIDE-PATH manuscript."""
import os, json, glob
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import networkx as nx
from dataset import ROOT
from simulator import SKILL_CODES, SKILL_DOMAIN, PREREQ, STRAT_CODES, DOMAINS, K, P

R, FIG = os.path.join(ROOT, "results"), os.path.join(ROOT, "figures")
CAT = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6"]
OURS, BASE = "#2a78d6", "#a3a29e"
INK, INK2, MUTED, GRID = "#0b0b0b", "#52514e", "#8a8985", "#e4e3df"
MARK = ["o", "s", "^", "D", "v", "P", "X"]
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.edgecolor": MUTED, "axes.linewidth": 0.8,
                     "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2, "axes.titlesize": 10,
                     "axes.titleweight": "bold", "axes.titlecolor": INK, "legend.frameon": False})


def clean(ax, grid="y"):
    for s in ["top", "right"]:
        ax.spines[s].set_visible(False)
    if grid:
        ax.grid(axis=grid, color=GRID, lw=0.7); ax.set_axisbelow(True)


def panel(ax, letter):
    ax.text(-0.12, 1.06, letter, transform=ax.transAxes, fontsize=11, weight="bold", color=INK, va="bottom")


def save(fig, name):
    fig.savefig(os.path.join(FIG, name), dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)


# ---------------------------------------------------------------- Fig 3: HSSG + PMGA attention
def fig_graph():
    g = json.load(open(os.path.join(R, "guidance.json")))
    att = np.array(g["pmga_attention"])                       # (P+1, K, K) row i <- source j
    neu = att[P]
    fig = plt.figure(figsize=(13, 5.6))
    ax = fig.add_axes([0.0, 0.02, 0.5, 0.92]); ax.axis("off"); panel(ax, "(a)")
    ax.set_title("HSSG with learned PMGA attention (neutral slot)", loc="left")
    G = nx.DiGraph()
    pos = {}
    for k in range(K):
        d = SKILL_DOMAIN[k]; j = k % 4
        ang = 2 * np.pi * d / 6 + (j - 1.5) * 0.17
        rad = 1.0 + 0.0 * j
        pos[k] = (rad * np.cos(ang), rad * np.sin(ang))
        G.add_node(k)
    edges, widths = [], []
    for j, i in zip(*np.nonzero(PREREQ)):
        edges.append((j, i)); widths.append(neu[i, j])
    widths = np.array(widths)
    for (j, i), w in zip(edges, widths):
        ax.annotate("", xy=pos[i], xytext=pos[j], arrowprops=dict(arrowstyle="-|>", color=INK2, lw=0.6 + 4 * w / widths.max(),
                    alpha=0.35 + 0.6 * w / widths.max(), shrinkA=9, shrinkB=9, connectionstyle="arc3,rad=0.12"))
    for k in range(K):
        c = CAT[SKILL_DOMAIN[k]] if SKILL_DOMAIN[k] < 6 else BASE
        ax.scatter(*pos[k], s=520, color=c, edgecolor="white", lw=2, zorder=3)
        ax.text(*pos[k], SKILL_CODES[k], ha="center", va="center", fontsize=7.5, color="white", weight="bold", zorder=4)
    for d in range(6):
        ang = 2 * np.pi * d / 6
        ax.text(1.32 * np.cos(ang), 1.32 * np.sin(ang), DOMAINS[d], ha="center", va="center", fontsize=9, color=INK2)
    ax.set_xlim(-1.5, 1.5); ax.set_ylim(-1.45, 1.45); ax.set_aspect("equal")
    ax.text(0, -1.42, "edge width/opacity ∝ attention that a dependent skill pays to its prerequisite", ha="center",
            fontsize=8, color=MUTED)
    # (b) strategy x edge-type attention mass relative to neutral
    from dataset import skill_graph
    E = skill_graph()
    types = [(1, "self"), (2, "prerequisite"), (3, "dependent"), (4, "peer")]
    M = np.zeros((P, len(types)))
    for p in range(P):
        for c, (t, _) in enumerate(types):
            M[p, c] = (att[p][E == t].sum() - neu[E == t].sum()) / K
    ax2 = fig.add_axes([0.6, 0.14, 0.33, 0.72]); panel(ax2, "(b)")
    v = np.abs(M).max()
    im = ax2.imshow(M, cmap="RdBu_r", vmin=-v, vmax=v, aspect="auto")
    ax2.set_xticks(range(len(types))); ax2.set_xticklabels([t[1] for t in types], rotation=20)
    ax2.set_yticks(range(P)); ax2.set_yticklabels(STRAT_CODES)
    for p in range(P):
        for c in range(len(types)):
            ax2.text(c, p, f"{M[p, c]:+.3f}", ha="center", va="center", fontsize=7.5,
                     color="white" if abs(M[p, c]) > 0.6 * v else INK)
    ax2.set_title("Strategy-induced change of attention mass\nper edge type (vs. neutral slot)", loc="left")
    cb = fig.colorbar(im, ax=ax2, fraction=0.05, pad=0.03); cb.outline.set_visible(False)
    save(fig, "Fig8_hssg_pmga_attention.png")


# ---------------------------------------------------------------- Fig 4: KT
def fig_kt():
    s = json.load(open(os.path.join(R, "kt_summary.json")))
    order = ["BKT", "PFA", "DKT", "SAKT", "AKT", "GAT-KT", "GUIDE"]
    order = [o for o in order if o in s["summary"]]
    fig, axs = plt.subplots(1, 3, figsize=(13, 3.8), gridspec_kw=dict(width_ratios=[1.1, 1.2, 1.0]))
    ax = axs[0]; panel(ax, "(a)")
    y = np.arange(len(order))
    for i, o in enumerate(order):
        m, sd = s["summary"][o]["AUC"]
        c = OURS if o == "GUIDE" else BASE
        ax.errorbar(m, i, xerr=sd, fmt="o", color=c, ms=7, capsize=3, lw=1.5)
        ax.text(m + 0.004, i, f"{m:.4f}", va="center", fontsize=8, color=INK2)
    ax.set_yticks(y); ax.set_yticklabels(order); ax.set_xlabel("Test AUC (mean ± s.d. over seeds)")
    ax.set_title("Knowledge-tracing accuracy", loc="left"); clean(ax, "x")
    lo = min(s["summary"][o]["AUC"][0] for o in order)
    ax.set_xlim(lo - 0.01, max(s["summary"][o]["AUC"][0] for o in order) + 0.02)
    ax = axs[1]; panel(ax, "(b)")
    labs = ["1–10", "11–25", "26–50", "51–100"]
    for i, o in enumerate(["DKT", "SAKT", "AKT", "GAT-KT", "GUIDE"]):
        if o not in s["by_position"]:
            continue
        c = OURS if o == "GUIDE" else CAT[[1, 2, 3, 6][i] if i < 4 else 0]
        ax.plot(labs, s["by_position"][o], marker=MARK[i], color=c, lw=2 if o == "GUIDE" else 1.4, ms=6, label=o)
    ax.set_xlabel("History position of the predicted interaction"); ax.set_ylabel("AUC (seed-averaged)")
    ax.set_title("Accuracy along the learning history", loc="left"); clean(ax); ax.legend(fontsize=8, ncol=2)
    ax = axs[2]; panel(ax, "(c)")
    deep = [o for o in ["DKT", "SAKT", "AKT", "GAT-KT", "GUIDE"] if o in s["summary"]]
    for i, o in enumerate(deep):
        m, sd = s["summary"][o]["SEH_AUC"]
        c = OURS if o == "GUIDE" else BASE
        ax.errorbar(m, i, xerr=sd, fmt="s", color=c, ms=7, capsize=3, lw=1.5)
        ax.text(m + 0.0015, i, f"{m:.4f}", va="center", fontsize=8, color=INK2)
    ax.set_yticks(range(len(deep))); ax.set_yticklabels(deep); ax.set_xlabel("Delayed-outcome AUC (SEH)")
    ax.set_title("Strategy-Efficacy Head accuracy", loc="left"); clean(ax, "x")
    ax.set_xlim(min(s["summary"][o]["SEH_AUC"][0] for o in deep) - 0.004, max(s["summary"][o]["SEH_AUC"][0] for o in deep) + 0.006)
    fig.tight_layout(); save(fig, "Fig3_knowledge_tracing.png")


# ---------------------------------------------------------------- Fig 5: strategy guidance
def gmean(g, name, m):
    v = g["policies"].get(name)
    return (np.mean([x[m] for x in v]), np.std([x[m] for x in v])) if v else (np.nan, 0)


GUIDE_POL = ["Random", "Popularity", "Teacher rule (logging policy)", "Contextual IPW-LR bandit",
             "GUIDE w/o SEH (immediate-correctness ranking)", "DKT [learned uplift only]", "SAKT [learned uplift only]",
             "AKT [learned uplift only]", "GAT-KT [learned uplift only]", "GUIDE [learned uplift only]",
             "PKB only (calibrated, no learned uplift)", "GUIDE-PATH EPSG (PKB + uplift, LGWO-calibrated)"]
SHORT = {"Teacher rule (logging policy)": "Teacher rule", "Contextual IPW-LR bandit": "Contextual bandit",
         "GUIDE w/o SEH (immediate-correctness ranking)": "Immediate-correctness rank",
         "PKB only (calibrated, no learned uplift)": "PKB only",
         "GUIDE-PATH EPSG (PKB + uplift, LGWO-calibrated)": "GUIDE-PATH EPSG"}


def short(n):
    return SHORT.get(n, n.replace(" [learned uplift only]", " uplift"))


def fig_guidance():
    g = json.load(open(os.path.join(R, "guidance.json")))
    pols = [p for p in GUIDE_POL if p in g["policies"]]
    fig = plt.figure(figsize=(13, 5.4))
    for j, (m, lab) in enumerate([("NDCG3", "NDCG@3 (↑)"), ("Regret", "Normalised regret (↓)")]):
        ax = fig.add_axes([0.13 + j * 0.25, 0.1, 0.17, 0.8]); panel(ax, "(a)" if j == 0 else "(b)")
        vals = [gmean(g, p, m) for p in pols]
        yy = np.arange(len(pols))
        ax.barh(yy, [v[0] for v in vals], xerr=[v[1] for v in vals], height=0.7,
                color=[OURS if "EPSG" in p else BASE for p in pols], error_kw=dict(lw=0.8, capsize=2, color=INK2))
        for y_, v in zip(yy, vals):
            ax.text(v[0] + v[1] + 0.012, y_, f"{v[0]:.3f}", va="center", fontsize=7.5, color=INK2)
        ax.set_yticks(yy); ax.set_yticklabels([short(p) for p in pols] if j == 0 else [])
        ax.set_xlabel(lab); clean(ax, "x"); ax.invert_yaxis()
        ax.set_xlim(0, max(v[0] + v[1] for v in vals) * 1.25)
    it = g["interpretability"]
    for j, (key, ttl) in enumerate([("oracle", "Oracle-best strategy"), ("model", "GUIDE-PATH EPSG recommendation")]):
        ax = fig.add_axes([0.66, 0.56 - j * 0.45, 0.3, 0.33]); panel(ax, "(c)" if j == 0 else "(d)")
        M = np.array(it[key], float); M = M / M.sum(1, keepdims=True)
        im = ax.imshow(M, cmap="Blues", vmin=0, vmax=max(0.5, M.max()), aspect="auto")
        ax.set_yticks(range(3)); ax.set_yticklabels(["low", "mid", "high"]); ax.set_ylabel("true mastery")
        ax.set_xticks(range(P)); ax.set_xticklabels(STRAT_CODES)
        for a_ in range(3):
            for b_ in range(P):
                ax.text(b_, a_, f"{M[a_, b_]:.2f}", ha="center", va="center", fontsize=7,
                        color="white" if M[a_, b_] > 0.3 else INK)
        ax.set_title(ttl, loc="left", fontsize=9.5)
    save(fig, "Fig4_strategy_guidance.png")


# ---------------------------------------------------------------- Fig 6: learning paths
MAIN = ["Random", "Teacher rule", "DKT-Greedy", "GUIDE-Greedy", "GUIDE+GA", "GUIDE+PSO", "GUIDE+GWO", "GUIDE-PATH (ZPD-LGWO)"]


def load_paths():
    out = {}
    for f in glob.glob(os.path.join(R, "paths", "*.csv")):
        if "_n600" in f:
            continue
        df = pd.read_csv(f); out[df.policy.iloc[0]] = df
    return out


def fig_paths():
    P_ = load_paths()
    pols = [p for p in MAIN if p in P_]
    fig, axs = plt.subplots(1, 3, figsize=(13.5, 4.3), gridspec_kw=dict(width_ratios=[1.35, 1.2, 1.0]))
    ax = axs[0]; panel(ax, "(a)")
    data = [P_[p].Ep.values for p in pols]
    bp = ax.boxplot(data, vert=False, widths=0.6, patch_artist=True, showfliers=False,
                    medianprops=dict(color=INK, lw=1.4), whiskerprops=dict(color=MUTED), capprops=dict(color=MUTED))
    for patch, p in zip(bp["boxes"], pols):
        patch.set_facecolor(OURS if "LGWO" in p else "#e9e8e4"); patch.set_edgecolor(OURS if "LGWO" in p else MUTED)
    for i, d in enumerate(data):
        ax.plot(d.mean(), i + 1, marker="D", color=INK, ms=4)
    ax.set_yticks(range(1, len(pols) + 1)); ax.set_yticklabels([p.replace(" (ZPD-LGWO)", "\n(ZPD-LGWO)") for p in pols])
    ax.set_xlabel("Normalised learning gain $E_p$ on target sub-skills"); clean(ax, "x")
    ax.set_title("Learning gain after 20 steps (◆ = mean)", loc="left")
    ax = axs[1]; panel(ax, "(b)")
    yy = np.arange(1, len(pols) + 1); h = 0.38
    imm = [P_[p].Ep.mean() for p in pols]; ret = [P_[p].Ep_ret.mean() for p in pols]
    ax.barh(yy + h / 2, imm, h, color=CAT[0], label="immediate $E_p$")
    ax.barh(yy - h / 2, ret, h, color=CAT[1], label="after 7 days $E_p^{7d}$")
    ax.set_yticks(yy); ax.set_yticklabels([]); clean(ax, "x")
    for y_, a, b in zip(yy, imm, ret):
        ax.text(a + 0.005, y_ + h / 2, f"{a:.3f}", va="center", fontsize=7.2, color=INK2)
        ax.text(b + 0.005, y_ - h / 2, f"{b:.3f}", va="center", fontsize=7.2, color=INK2)
    ax.legend(loc="lower right", fontsize=8); ax.set_xlabel("Mean normalised gain")
    ax.set_title("Immediate vs. retained gain", loc="left"); ax.set_xlim(0, max(imm) * 1.25)
    ax = axs[2]; panel(ax, "(c)")
    gph = [P_[p].gain_per_hour.mean() for p in pols]
    ax.barh(yy, gph, 0.65, color=[OURS if "LGWO" in p else BASE for p in pols])
    for y_, v in zip(yy, gph):
        ax.text(v + 0.002, y_, f"{v:.3f}", va="center", fontsize=7.5, color=INK2)
    ax.set_yticks(yy); ax.set_yticklabels([]); clean(ax, "x")
    ax.set_xlabel("Mastery gain per study hour"); ax.set_title("Learning efficiency", loc="left")
    ax.set_xlim(0, max(gph) * 1.25)
    for a_ in axs:
        a_.set_ylim(0.4, len(pols) + 0.6)
    fig.tight_layout(); save(fig, "Fig5_learning_paths.png")


# ---------------------------------------------------------------- Fig 7: optimisation behaviour
def fig_convergence():
    fig, axs = plt.subplots(1, 4, figsize=(15, 3.7))
    ax = axs[0]; panel(ax, "(a)")
    names = [("GUIDE+GA", "GA"), ("GUIDE+PSO", "PSO"), ("GUIDE+GWO", "GWO"), ("GUIDE-PATH (ZPD-LGWO)", "ZPD-LGWO")]
    cols = [CAT[1], CAT[2], CAT[3], OURS]
    for (n, lab), c, mk in zip(names, cols, MARK):
        f = os.path.join(R, "paths", n.replace("/", "_").replace(" ", "_").replace("(", "").replace(")", "") + "_curve.json")
        if os.path.exists(f):
            d = json.load(open(f)); x = np.array(d["grid"]); yv = -np.array(d["mean"])
            ax.plot(x, yv, color=c, lw=2 if "LGWO" in lab else 1.4, label=lab, marker=mk, markevery=10, ms=5)
    ax.set_xlabel("Function evaluations"); ax.set_ylabel("Best path fitness J (mean)")
    ax.set_title("Path-planning convergence", loc="left"); clean(ax); ax.legend(fontsize=8)
    b = json.load(open(os.path.join(R, "benchmark_optimizers.json")))
    for j, fn in enumerate(["F4 Schwefel 2.21", "F9 Ackley"]):
        ax = axs[1 + j]; panel(ax, "(b)" if j == 0 else "(c)")
        x = np.linspace(b["pop"], b["max_fe"], 100)
        for i, a in enumerate(b["algs"]):
            c = OURS if a == "LGWO" else CAT[1:][i % 6]
            ax.plot(x, b["curves"][fn][a], color=c, lw=2 if a == "LGWO" else 1.2, label=a, marker=MARK[i], markevery=12, ms=4.5)
        ax.set_yscale("log"); ax.set_xlabel("Function evaluations"); ax.set_ylabel("Best error (mean of 30 runs)")
        ax.set_title(f"Benchmark {fn} (D = 30, shifted)", loc="left"); clean(ax)
        if j == 0:
            ax.legend(fontsize=7.2, ncol=2)
    ax = axs[3]; panel(ax, "(d)")
    h = json.load(open(os.path.join(R, "hpo.json")))
    for i, (k, c) in enumerate([("LGWO", OURS), ("GWO", CAT[3]), ("RandomSearch", CAT[1])]):
        fe, best = np.array(h[k]["curve"]).T
        ax.step(fe, -best, where="post", color=c, lw=2 if k == "LGWO" else 1.4, label=k, marker=MARK[i], ms=5)
    ax.axhline(-h["default_fitness"], color=MUTED, ls="--", lw=1); ax.text(1, -h["default_fitness"] + 0.001, "default config", fontsize=7.5, color=MUTED)
    ax.set_xlabel("Evaluations (short trainings)"); ax.set_ylabel("val AUC + 0.5·val SEH-AUC")
    ax.set_title("Hyper-parameter search", loc="left"); clean(ax); ax.legend(fontsize=8, loc="center right")
    fig.tight_layout(); save(fig, "Fig7_optimisation.png")


# ---------------------------------------------------------------- Fig 8: ablation & sensitivity
def fig_ablation():
    s = json.load(open(os.path.join(R, "kt_summary.json")))
    g = json.load(open(os.path.join(R, "guidance.json")))
    P_ = load_paths()
    fig, axs = plt.subplots(1, 4, figsize=(15, 3.9), gridspec_kw=dict(width_ratios=[1, 1, 1.1, 0.9]))
    ab = [("GUIDE", "Full GUIDE"), ("GUIDE-noPMGA", "w/o PMGA"), ("GUIDE-noFiLM", "w/o strategy FiLM"),
          ("GUIDE-noDecay", "w/o forgetting decay"), ("GUIDE-noRel", "w/o relation bias"),
          ("GUIDE-noIPW", "w/o IPW"), ("GUIDE-default", "w/o LGWO-HPO")]
    ab = [a for a in ab if a[0] in s["summary"]]
    ax = axs[0]; panel(ax, "(a)")
    for i, (k, lab) in enumerate(ab):
        m, sd = s["summary"][k]["AUC"]
        ax.errorbar(m, i, xerr=sd, fmt="o", color=OURS if k == "GUIDE" else BASE, ms=6, capsize=3)
    ax.set_yticks(range(len(ab))); ax.set_yticklabels([a[1] for a in ab]); ax.invert_yaxis()
    ax.set_xlabel("Test AUC"); ax.set_title("Encoder ablation: KT", loc="left"); clean(ax, "x")
    ax = axs[1]; panel(ax, "(b)")
    for i, (k, lab) in enumerate(ab):
        nm = "GUIDE-PATH EPSG (PKB + uplift, LGWO-calibrated)" if k == "GUIDE" else f"{k} + EPSG"
        m, sd = gmean(g, nm, "NDCG3")
        ax.errorbar(m, i, xerr=sd, fmt="s", color=OURS if k == "GUIDE" else BASE, ms=6, capsize=3)
    ax.set_yticks(range(len(ab))); ax.set_yticklabels([]); ax.invert_yaxis()
    ax.set_xlabel("Guidance NDCG@3"); ax.set_title("Encoder ablation: guidance", loc="left"); clean(ax, "x")
    ax = axs[2]; panel(ax, "(c)")
    pa = ["GUIDE-PATH (ZPD-LGWO)", "w/o ZPD repair", "w/o seeded init", "w/o EPSG prior", "w/o rollout gain",
          "w/o need-readiness"]
    pa = [p for p in pa if p in P_]
    vals = [P_[p].Ep.mean() for p in pa]; err = [P_[p].Ep.std() / np.sqrt(len(P_[p])) for p in pa]
    ax.barh(range(len(pa)), vals, 0.65, xerr=err, color=[OURS if i == 0 else BASE for i in range(len(pa))],
            error_kw=dict(lw=0.8, capsize=2, color=INK2))
    for i, (v, e_) in enumerate(zip(vals, err)):
        ax.text(v + e_ + 0.008, i, f"{v:.3f}", va="center", fontsize=7.5, color=INK2)
    ax.set_yticks(range(len(pa))); ax.set_yticklabels([p.replace(" (ZPD-LGWO)", "") for p in pa]); ax.invert_yaxis()
    ax.set_xlabel("Mean $E_p$ (± s.e.)"); ax.set_title("PATH ablation", loc="left"); clean(ax, "x")
    ax.set_xlim(0, max(vals) * 1.3)
    ax = axs[3]; panel(ax, "(d)")
    hs = [("H=5", 5), ("GUIDE-PATH (ZPD-LGWO)", 10), ("H=20", 20)]
    pts = [(h, P_[n].Ep.mean(), P_[n].Ep.std() / np.sqrt(len(P_[n]))) for n, h in hs if n in P_]
    if pts:
        x, yv, e = zip(*pts)
        ax.errorbar(x, yv, yerr=e, marker="o", color=OURS, lw=2, ms=6, capsize=3, label="test, planning horizon H")
    lt = json.load(open(os.path.join(R, "path_lambda.json")))["grid"]
    for i, lu in enumerate(sorted({r["u"] for r in lt})):
        rr = sorted([r for r in lt if r["u"] == lu], key=lambda r: r["n"])
    ax.set_xticks([5, 10, 20]); ax.set_xlabel("Planning horizon H (re-plan every H steps)"); ax.set_ylabel("Mean $E_p$")
    ax.set_title("Sensitivity to horizon", loc="left"); clean(ax)
    fig.tight_layout(); save(fig, "Fig6_ablation_sensitivity.png")


# ---------------------------------------------------------------- Fig 9: case study
def fig_case():
    cs = json.load(open(os.path.join(R, "case_study.json")))
    fig, axs = plt.subplots(2, 1, figsize=(12.5, 6.2), sharex=True, gridspec_kw=dict(height_ratios=[1.6, 1]))
    ax = axs[0]; panel(ax, "(a)")
    for name, c, ls in [("Teacher rule", CAT[1], "--"), ("GUIDE-PATH", OURS, "-")]:
        tr = cs["runs"][name]["trace"]
        M = np.array([t["mastery"] for t in tr]).mean(1)
        pre = cs["runs"][name]["summary"]["pre"]
        ax.plot(range(0, len(M) + 1), [pre] + list(M), color=c, lw=2, ls=ls, marker="o", ms=4, label=name)
    ax.set_ylabel("True mean target mastery"); clean(ax)
    ax.legend(fontsize=8.5, loc="upper left")
    ax.set_title(f"Learner {cs['learner']} — goal domain {DOMAINS[cs['domain']]} (targets {', '.join(cs['targets'])})", loc="left")
    ax = axs[1]; panel(ax, "(b)")
    for row, (name, c) in enumerate([("Teacher rule", CAT[1]), ("GUIDE-PATH", OURS)]):
        tr = cs["runs"][name]["trace"]
        for i, t in enumerate(tr):
            ax.add_patch(plt.Rectangle((i + 0.55, row - 0.38), 0.9, 0.76, color=c if t["correct"] else "white",
                                       ec=c, lw=1.2, alpha=0.9 if t["correct"] else 1))
            ax.text(i + 1, row + 0.12, t["strategy"], ha="center", va="center", fontsize=7,
                    color="white" if t["correct"] else INK, weight="bold")
            ax.text(i + 1, row - 0.17, t["skill"], ha="center", va="center", fontsize=6.5,
                    color="white" if t["correct"] else INK2)
    ax.set_yticks([0, 1]); ax.set_yticklabels(["Teacher rule", "GUIDE-PATH"]); ax.set_ylim(-0.6, 1.6)
    ax.set_xlim(0, 21); ax.set_xticks(range(1, 21)); ax.set_xlabel("Step (filled = correct response; text = strategy / sub-skill)")
    for s_ in ["top", "right"]:
        ax.spines[s_].set_visible(False)
    fig.tight_layout(); save(fig, "Fig9_case_study.png")


if __name__ == "__main__":
    import sys
    which = sys.argv[1:] or ["graph", "kt", "guidance", "paths", "convergence", "ablation", "case"]
    for w in which:
        try:
            globals()["fig_" + w]()
            print("ok", w)
        except Exception as e:
            print("FAILED", w, repr(e))
