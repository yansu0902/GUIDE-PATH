"""Per-learner paired Wilcoxon tests for strategy guidance (seed 0 models, 600 test learners)."""
import os, json
import numpy as np
from scipy.stats import wilcoxon
from dataset import Corpus, ROOT
from train_kt import predict
from run_guidance import load_model
from strategy_eval import Oracle, rule_scores
from guidance import fused_scores, pkb_features, prev3_from_logs
from simulator import SKILL_DOMAIN, sig

R = os.path.join(ROOT, "results")


def regret_per_learner(scores, G):
    a = scores.argmax(-1)
    ch = np.take_along_axis(G, a[..., None], -1)[..., 0]
    gmax, gmin = G.max(-1), G.min(-1)
    return ((gmax - ch) / (gmax - gmin + 1e-12)).mean(1)


def main():
    C = Corpus(); O = Oracle(C); te = O.ids
    g = json.load(open(os.path.join(R, "guidance.json")))
    th = np.array(g["epsg_theta"]["0"]["theta"])
    m = load_model(C, "GUIDE", 0); pt = predict(m, C, te, all_strats=True)
    mh = sig(pt["kt_neutral"])
    dom, rep = pkb_features(mh, SKILL_DOMAIN[C.cur.primary[C.items[te]]], prev3_from_logs(C.strat[te]))
    th0 = th.copy(); th0[3] = 0
    pg = predict(load_model(C, "GAT-KT", 0), C, te, all_strats=True)
    sc = {"GUIDE-PATH EPSG": fused_scores(th, mh, dom, rep, pt["seh_all"]),
          "PKB only": fused_scores(th0, mh, dom, rep, pt["seh_all"]),
          "GUIDE uplift only": pt["seh_all"], "GAT-KT uplift only": pg["seh_all"],
          "Teacher rule": rule_scores(C, te, np.random.default_rng(1)),
          "Immediate-correctness rank": pt["kt_all"],
          "Random": np.random.default_rng(0).random(O.G.shape)}
    reg = {k: regret_per_learner(v, O.G) for k, v in sc.items()}
    out = {}
    for k, v in reg.items():
        if k == "GUIDE-PATH EPSG":
            continue
        d = v - reg["GUIDE-PATH EPSG"]
        out[k] = dict(regret=float(v.mean()), epsg_regret=float(reg["GUIDE-PATH EPSG"].mean()),
                      mean_reduction=float(d.mean()), p=float(wilcoxon(reg["GUIDE-PATH EPSG"], v).pvalue),
                      win_rate=float((d > 0).mean()))
        print(k, out[k])
    json.dump(out, open(os.path.join(R, "guidance_stats.json"), "w"), indent=1)


if __name__ == "__main__":
    main()
