"""Explicit Pedagogical Strategy Guidance (EPSG):
Pedagogical Knowledge Base (PKB) priors  (+)  learned, IPW-debiased strategy uplift (SEH),
fused with weights calibrated by LGWO on an off-policy (SNIPS) estimate of the delayed learning outcome.
"""
import numpy as np
from simulator import P, SKILL_DOMAIN, STRAT_CODES

# ---------------------------------------------------------------- Pedagogical Knowledge Base
# R1-R3 expertise-reversal / ZPD / desirable-difficulty rules (mastery bands)
BAND_RULES = {0: [0, 1, 7],      # novice      -> explicit instruction, worked examples, gamified drill
              1: [2, 4, 6],      # developing  -> scaffolded practice, corrective feedback, collaborative
              2: [3, 5]}         # proficient  -> retrieval practice, task-based communicative tasks
# R4 domain-specific evidence (V, G, R, L, S, W)
DOMAIN_RULES = {0: [3, 7], 1: [1, 4], 2: [2, 6], 3: [5, 2], 4: [5, 4], 5: [4, 1]}
PKB_TEXT = [
    ("R1", "Expertise reversal", "If estimated mastery < t1 favour EI, WE, GD"),
    ("R2", "Zone of proximal development", "If t1 <= mastery < t2 favour SP, CF, CL"),
    ("R3", "Desirable difficulties / testing effect", "If mastery >= t2 favour RP, TB"),
    ("R4", "Domain evidence", "V: RP, GD; G: WE, CF; R: SP, CL; L: TB, SP; S: TB, CF; W: CF, WE"),
    ("R5", "Variety / habituation", "Penalise a strategy used in each of the last three steps"),
]


def pkb_features(m_hat, domain, prev3):
    """m_hat (...,) estimated mastery; domain (...,) int; prev3 (...,3) previous strategies (-1 = none).
    Returns band (...,P,3 one-hot of matched band rule), dom (...,P), rep (...,P)."""
    sh = m_hat.shape
    band_idx = None
    dom = np.zeros(sh + (P,))
    for d_, ss in DOMAIN_RULES.items():
        sel = domain == d_
        dom[sel] = 0
        for s_ in ss:
            dom[sel, s_] = 1.0
    rep = np.zeros(sh + (P,))
    same = (prev3[..., 0] == prev3[..., 1]) & (prev3[..., 1] == prev3[..., 2]) & (prev3[..., 0] >= 0)
    idx = np.where(same, prev3[..., 0], 0)
    oh = np.eye(P)[idx] * same[..., None]
    rep += oh
    return dom, rep


def band_scores(m_hat, t1, t2):
    out = np.zeros(m_hat.shape + (P,))
    b = np.where(m_hat < t1, 0, np.where(m_hat < t2, 1, 2))
    for k, ss in BAND_RULES.items():
        sel = b == k
        for s_ in ss:
            out[sel, s_] = 1.0
    return out


def zscore(u):
    return (u - u.mean(-1, keepdims=True)) / (u.std(-1, keepdims=True) + 1e-6)


def fused_scores(theta, m_hat, dom, rep, uplift):
    """theta = (w_m, w_d, w_v, kappa, t1, t2)."""
    w_m, w_d, w_v, kap, t1, t2 = theta
    return w_m * band_scores(m_hat, t1, t2) + w_d * dom - w_v * rep + kap * zscore(uplift)


CAL_LB = np.array([0, 0, 0, 0, 0.2, 0.55])
CAL_UB = np.array([2, 2, 2, 2, 0.5, 0.85])
DEFAULT_THETA = np.array([1.0, 1.0, 1.0, 1.0, 0.4, 0.7])


def prev3_from_logs(S):
    """S (n,T) logged strategies -> (n,T,3) previous three strategies."""
    n, T = S.shape
    pad = np.concatenate([-np.ones((n, 3), int), S], 1)
    return np.stack([pad[:, 2:T + 2], pad[:, 1:T + 1], pad[:, 0:T]], -1)


def snips_residual(actions, logged, prop, y, base, mask):
    """Self-normalised IPS estimate of the delayed-outcome residual (y - baseline) of a deterministic policy."""
    match = (actions == logged) & (mask > 0)
    w = match / prop
    return float((w * (y - base)).sum() / max(w.sum(), 1e-9)), int(match.sum())


class Calibrator:
    """Holds validation-log inputs and evaluates candidate fusion weights with SNIPS."""

    def __init__(self, C, ids, pred):
        self.C, self.ids = C, ids
        it = C.items[ids]
        self.m_hat = 1 / (1 + np.exp(-pred["kt_neutral"]))
        self.dom, self.rep = pkb_features(self.m_hat, SKILL_DOMAIN[C.cur.primary[it]], prev3_from_logs(C.strat[ids]))
        self.uplift = pred["seh_all"]
        self.base = 1 / (1 + np.exp(-pred["seh_base"]))
        self.logged, self.prop = C.strat[ids], C.prop[ids]
        self.y, self.mask = C.yg[ids], C.mg[ids]

    def value(self, theta):
        a = fused_scores(theta, self.m_hat, self.dom, self.rep, self.uplift).argmax(-1)
        return snips_residual(a, self.logged, self.prop, self.y, self.base, self.mask)[0]

    def objective(self, X):
        return np.array([-self.value(x) for x in X])
