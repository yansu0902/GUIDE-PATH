"""KT result aggregation: mean±sd over seeds, AUC by history position, ROC data, per-learner Wilcoxon tests."""
import os, json, glob
import numpy as np
from scipy.stats import wilcoxon, ttest_rel
from sklearn.metrics import roc_auc_score, roc_curve
from dataset import Corpus, ROOT
from train_kt import predict
from run_guidance import load_model, available

R = os.path.join(ROOT, "results")
MODELS = ["DKT", "SAKT", "AKT", "GAT-KT", "GUIDE", "GUIDE-noPMGA", "GUIDE-noFiLM", "GUIDE-noDecay", "GUIDE-noRel",
          "GUIDE-noSEH", "GUIDE-noIPW", "GUIDE-default"]


def main():
    C = Corpus()
    te = C.split["test"]
    y = C.resp[te]
    out = {"summary": {}, "by_position": {}, "roc": {}, "tests": {}, "per_learner_auc": {}}
    bins = [(0, 10), (10, 25), (25, 50), (50, 100)]
    for nm in MODELS:
        seeds = available(nm)
        if not seeds:
            continue
        res = [json.load(open(os.path.join(R, "models", f"{nm}_s{s}.json")))["result"] for s in seeds]
        out["summary"][nm] = {k: [float(np.mean([r[k] for r in res])), float(np.std([r[k] for r in res]))]
                              for k in ["AUC", "ACC", "RMSE", "BCE", "SEH_AUC", "train_sec", "epochs", "n_params"]}
        out["summary"][nm]["seeds"] = seeds
        out["summary"][nm]["AUC_per_seed"] = [r["AUC"] for r in res]
        if nm in ["DKT", "SAKT", "AKT", "GAT-KT", "GUIDE"]:
            P = np.mean([predict(load_model(C, nm, s), C, te)["kt"] for s in seeds], 0)   # seed-averaged
            out["by_position"][nm] = [float(roc_auc_score(y[:, a:b].ravel(), P[:, a:b].ravel())) for a, b in bins]
            fpr, tpr, _ = roc_curve(y.ravel(), P.ravel())
            idx = np.linspace(0, len(fpr) - 1, 200).astype(int)
            out["roc"][nm] = [fpr[idx].tolist(), tpr[idx].tolist()]
            out["per_learner_auc"][nm] = [float(roc_auc_score(y[i], P[i])) if 0 < y[i].mean() < 1 else np.nan
                                          for i in range(len(te))]
    g = np.array(out["per_learner_auc"]["GUIDE"])
    for nm in ["DKT", "SAKT", "AKT", "GAT-KT"]:
        b = np.array(out["per_learner_auc"][nm]); m = ~np.isnan(g) & ~np.isnan(b)
        w = wilcoxon(g[m], b[m])
        sg = out["summary"]["GUIDE"]["AUC_per_seed"]; sb = out["summary"][nm]["AUC_per_seed"]
        n = min(len(sg), len(sb))
        t = ttest_rel(sg[:n], sb[:n])
        out["tests"][nm] = dict(mean_diff_learner_auc=float(np.mean(g[m] - b[m])), wilcoxon_p=float(w.pvalue),
                                seed_ttest_p=float(t.pvalue), seed_mean_diff=float(np.mean(sg) - np.mean(sb)))
    out["bins"] = bins
    cl = json.load(open(os.path.join(R, "classic_kt.json")))
    for k, v in cl.items():
        out["summary"][k] = {m: [v[m], 0.0] for m in ["AUC", "ACC", "RMSE", "BCE"]}
    json.dump(out, open(os.path.join(R, "kt_summary.json"), "w"))
    for k, v in out["summary"].items():
        print(f"{k:15s} AUC {v['AUC'][0]:.4f}±{v['AUC'][1]:.4f} ACC {v['ACC'][0]:.4f} RMSE {v['RMSE'][0]:.4f}")
    print(json.dumps(out["tests"], indent=1)); print(out["by_position"])


if __name__ == "__main__":
    main()
