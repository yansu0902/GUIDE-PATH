#!/bin/bash
# Full GUIDE-PATH pipeline (CPU only). Approximate single-core times in brackets.
set -e
cd "$(dirname "$0")"
export OMP_NUM_THREADS=1
python autograd.py                       # gradient check of the NumPy autodiff engine       [<1 s]
python generate_data.py                  # EngPath-Sim corpus -> ../data/raw, ../data/ground_truth [1 min]
python bench_opt.py                      # optimiser benchmark (10 shifted functions x 30 runs) [5 min]
python baselines_classic.py              # BKT, PFA                                          [2 min]
python hpo.py                            # LGWO vs GWO vs random search for GUIDE            [20 min]
cp ../results/guide_best_hp.json ../results/guide_hp_file.json
python train_kt.py --models SAKT,AKT,GAT-KT,DKT --seeds 0,1,2,3,4                          # [~60 min]
python train_kt.py --models GUIDE --seeds 0,1,2,3,4 --hp ../results/guide_hp_file.json     # [~8 min]
python train_kt.py --models GUIDE-noPMGA,GUIDE-noFiLM,GUIDE-noDecay,GUIDE-noRel,GUIDE-noSEH,GUIDE-noIPW --seeds 0,1,2 --hp ../results/guide_hp_file.json  # [~30 min]
python train_kt.py --models GUIDE --seeds 0,1,2 --tag -default                             # [~8 min]
python calibrate_theta.py                # EPSG weights on validation logs (LGWO + SNIPS)    [1 min]
python tune_lambda.py                    # PATH weights on 30 validation learners            [8 min]
python run_paths.py --n 150 --policies "GUIDE-PATH (ZPD-LGWO),Random,Teacher rule,GUIDE-Greedy,GUIDE+GWO,GUIDE+PSO,GUIDE+GA,DKT-Greedy"
python run_paths.py --n 150 --policies "w/o ZPD repair,w/o EPSG prior,w/o seeded init,w/o rollout gain,w/o need-readiness,H=5,H=20"
python run_guidance.py                   # strategy-guidance evaluation vs oracle            [10 min]
python kt_analysis.py                    # KT tables, AUC by position, significance tests    [5 min]
python path_stats.py                     # path summary + Wilcoxon tests
python case_study.py                     # single-learner trajectory
python fig_diagrams.py && python fig_results.py
python build_paper.py                    # manuscript (.md -> .docx via pandoc)
