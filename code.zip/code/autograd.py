"""Minimal reverse-mode automatic differentiation on NumPy arrays (float32).

Written so that every model in GUIDE-PATH runs on a plain CPU with only NumPy installed.
Supports broadcasting, batched matmul, fancy indexing (embeddings) and fused kernels for
softmax, layer-norm and binary cross-entropy with logits.
"""
import numpy as np

DT = np.float32


def _unbroadcast(g, shape):
    if g.shape == shape:
        return g
    while g.ndim > len(shape):
        g = g.sum(0)
    for i, s in enumerate(shape):
        if s == 1 and g.shape[i] != 1:
            g = g.sum(i, keepdims=True)
    return g


class Tensor:
    __slots__ = ("data", "grad", "_prev", "_bw", "requires_grad")

    def __init__(self, data, requires_grad=False, _prev=(), _bw=None):
        self.data = data.astype(DT, copy=False) if isinstance(data, np.ndarray) else np.asarray(data, DT)
        self.grad = None
        self._prev = _prev
        self._bw = _bw
        self.requires_grad = requires_grad

    shape = property(lambda self: self.data.shape)
    ndim = property(lambda self: self.data.ndim)

    def __repr__(self):
        return f"Tensor(shape={self.shape})"

    def backward(self):
        topo, seen = [], set()
        stack = [(self, False)]
        while stack:                                   # iterative DFS (deep LSTM graphs)
            v, done = stack.pop()
            if done:
                topo.append(v); continue
            if id(v) in seen:
                continue
            seen.add(id(v))
            stack.append((v, True))
            for p in v._prev:
                if p.requires_grad and id(p) not in seen:
                    stack.append((p, False))
        self.grad = np.ones_like(self.data)
        for v in reversed(topo):
            if v._bw is not None and v.grad is not None:
                v._bw(v.grad)
                if v._prev:                            # free graph memory
                    v._bw = None

    # operator sugar
    def __add__(self, o): return add(self, o)
    def __radd__(self, o): return add(o, self)
    def __sub__(self, o): return sub(self, o)
    def __rsub__(self, o): return sub(o, self)
    def __mul__(self, o): return mul(self, o)
    def __rmul__(self, o): return mul(o, self)
    def __truediv__(self, o): return div(self, o)
    def __neg__(self): return mul(self, -1.0)
    def __matmul__(self, o): return matmul(self, o)
    def __getitem__(self, idx): return getitem(self, idx)


def T(x):
    return x if isinstance(x, Tensor) else Tensor(np.asarray(x, DT))


def _acc(t, g):
    if not t.requires_grad:
        return
    t.grad = g if t.grad is None else t.grad + g


def _mk(data, parents, bw):
    rg = any(p.requires_grad for p in parents)
    return Tensor(data, rg, tuple(parents) if rg else (), bw if rg else None)


# ---------------------------------------------------------------- elementwise
def add(a, b):
    a, b = T(a), T(b)
    def bw(g):
        _acc(a, _unbroadcast(g, a.shape)); _acc(b, _unbroadcast(g, b.shape))
    return _mk(a.data + b.data, (a, b), bw)


def sub(a, b):
    a, b = T(a), T(b)
    def bw(g):
        _acc(a, _unbroadcast(g, a.shape)); _acc(b, _unbroadcast(-g, b.shape))
    return _mk(a.data - b.data, (a, b), bw)


def mul(a, b):
    a, b = T(a), T(b)
    def bw(g):
        if a.requires_grad: _acc(a, _unbroadcast(g * b.data, a.shape))
        if b.requires_grad: _acc(b, _unbroadcast(g * a.data, b.shape))
    return _mk(a.data * b.data, (a, b), bw)


def div(a, b):
    a, b = T(a), T(b)
    def bw(g):
        if a.requires_grad: _acc(a, _unbroadcast(g / b.data, a.shape))
        if b.requires_grad: _acc(b, _unbroadcast(-g * a.data / b.data ** 2, b.shape))
    return _mk(a.data / b.data, (a, b), bw)


def _unary(a, f, df):
    a = T(a)
    out = f(a.data)
    def bw(g):
        _acc(a, g * df(a.data, out))
    return _mk(out, (a,), bw)


def exp(a): return _unary(a, np.exp, lambda x, y: y)
def log(a): return _unary(a, lambda x: np.log(x), lambda x, y: 1.0 / x)
def tanh(a): return _unary(a, np.tanh, lambda x, y: 1 - y * y)
def sigmoid(a): return _unary(a, lambda x: 1 / (1 + np.exp(-x)), lambda x, y: y * (1 - y))
def relu(a): return _unary(a, lambda x: np.maximum(x, 0), lambda x, y: (x > 0).astype(DT))
def leaky_relu(a, s=0.2): return _unary(a, lambda x: np.where(x > 0, x, s * x), lambda x, y: np.where(x > 0, 1, s).astype(DT))
def elu(a): return _unary(a, lambda x: np.where(x > 0, x, np.expm1(np.minimum(x, 0))), lambda x, y: np.where(x > 0, 1, y + 1).astype(DT))
def softplus(a): return _unary(a, lambda x: np.logaddexp(0, x), lambda x, y: 1 / (1 + np.exp(-x)))


# ---------------------------------------------------------------- linear algebra / shape
def matmul(a, b):
    a, b = T(a), T(b)
    def bw(g):
        if a.requires_grad: _acc(a, _unbroadcast(g @ np.swapaxes(b.data, -1, -2), a.shape))
        if b.requires_grad: _acc(b, _unbroadcast(np.swapaxes(a.data, -1, -2) @ g, b.shape))
    return _mk(a.data @ b.data, (a, b), bw)


def reshape(a, shape):
    a = T(a)
    def bw(g):
        _acc(a, g.reshape(a.shape))
    return _mk(a.data.reshape(shape), (a,), bw)


def transpose(a, axes):
    a = T(a)
    inv = np.argsort(axes)
    def bw(g):
        _acc(a, np.transpose(g, inv))
    return _mk(np.transpose(a.data, axes), (a,), bw)


def sum_(a, axis=None, keepdims=False):
    a = T(a)
    def bw(g):
        if axis is not None and not keepdims:
            g = np.expand_dims(g, axis)
        _acc(a, np.broadcast_to(g, a.shape).astype(DT))
    return _mk(a.data.sum(axis=axis, keepdims=keepdims), (a,), bw)


def mean(a, axis=None, keepdims=False):
    a = T(a)
    n = a.data.size if axis is None else np.prod([a.shape[i] for i in np.atleast_1d(axis)])
    return mul(sum_(a, axis, keepdims), 1.0 / n)


def _is_basic(idx):
    idx = idx if isinstance(idx, tuple) else (idx,)
    return all(isinstance(i, (slice, int, type(None), type(Ellipsis))) for i in idx)


def getitem(a, idx):
    a = T(a)
    basic = _is_basic(idx)
    def bw(g):
        z = np.zeros_like(a.data)
        if basic:
            z[idx] = g
        else:
            np.add.at(z, idx, g)
        _acc(a, z)
    return _mk(a.data[idx], (a,), bw)


def embed(W, idx):
    """Row lookup W[idx] for an integer array of any shape (fast scatter-add backward)."""
    def bw(g):
        z = np.zeros_like(W.data)
        np.add.at(z, idx.ravel(), g.reshape(-1, W.shape[1]))
        _acc(W, z)
    return _mk(W.data[idx], (W,), bw)


def concat(ts, axis=-1):
    ts = [T(t) for t in ts]
    sizes = [t.shape[axis] for t in ts]
    splits = np.cumsum(sizes)[:-1]
    def bw(g):
        for t, gg in zip(ts, np.split(g, splits, axis=axis)):
            _acc(t, gg)
    return _mk(np.concatenate([t.data for t in ts], axis=axis), ts, bw)


# ---------------------------------------------------------------- fused kernels
def softmax(a, axis=-1, mask_add=None):
    a = T(a)
    x = a.data if mask_add is None else a.data + mask_add
    x = x - x.max(axis=axis, keepdims=True)
    e = np.exp(x)
    y = e / e.sum(axis=axis, keepdims=True)
    def bw(g):
        _acc(a, y * (g - (g * y).sum(axis=axis, keepdims=True)))
    return _mk(y, (a,), bw)


def layernorm(a, gamma, beta, eps=1e-5):
    a, gamma, beta = T(a), T(gamma), T(beta)
    mu = a.data.mean(-1, keepdims=True)
    xc = a.data - mu
    var = (xc ** 2).mean(-1, keepdims=True)
    inv = 1.0 / np.sqrt(var + eps)
    xh = xc * inv
    out = xh * gamma.data + beta.data
    D = a.shape[-1]
    def bw(g):
        if gamma.requires_grad: _acc(gamma, _unbroadcast(g * xh, gamma.shape))
        if beta.requires_grad: _acc(beta, _unbroadcast(g, beta.shape))
        if a.requires_grad:
            gx = g * gamma.data
            _acc(a, inv / D * (D * gx - gx.sum(-1, keepdims=True) - xh * (gx * xh).sum(-1, keepdims=True)))
    return _mk(out, (a, gamma, beta), bw)


def dropout(a, p, rng, train=True):
    if not train or p <= 0:
        return a
    m = (rng.random(a.shape) >= p).astype(DT) / (1 - p)
    return mul(a, m)


def bce_logits(z, y, w):
    """Weighted mean binary cross-entropy with logits. y, w are numpy arrays; w = 0 masks."""
    z = T(z)
    x = z.data
    loss = np.maximum(x, 0) - x * y + np.log1p(np.exp(-np.abs(x)))
    ws = max(float(w.sum()), 1e-8)
    val = np.asarray((loss * w).sum() / ws, DT)
    def bw(g):
        s = 1 / (1 + np.exp(-x))
        _acc(z, g * (s - y) * w / ws)
    return _mk(val, (z,), bw)


# ---------------------------------------------------------------- parameters & optimiser
class Params:
    def __init__(self, rng):
        self.rng = rng
        self.p = {}

    def get(self, name, shape, init="xavier", scale=1.0):
        if name not in self.p:
            if init == "xavier":
                fan_in, fan_out = (shape[-2], shape[-1]) if len(shape) >= 2 else (shape[0], shape[0])
                lim = scale * np.sqrt(6.0 / (fan_in + fan_out))
                v = self.rng.uniform(-lim, lim, shape)
            elif init == "normal":
                v = self.rng.normal(0, scale, shape)
            elif init == "zeros":
                v = np.zeros(shape)
            elif init == "ones":
                v = np.ones(shape)
            else:
                v = np.full(shape, float(init))
            self.p[name] = Tensor(v.astype(DT), requires_grad=True)
        return self.p[name]

    def state(self):
        return {k: v.data.copy() for k, v in self.p.items()}

    def load(self, st):
        for k, v in st.items():
            self.p[k].data = v.copy()

    def n_params(self):
        return int(sum(v.data.size for v in self.p.values()))


class AdamW:
    def __init__(self, params: Params, lr=3e-3, wd=1e-5, betas=(0.9, 0.999), clip=5.0):
        self.P, self.lr, self.wd, self.b1, self.b2, self.clip = params, lr, wd, betas[0], betas[1], clip
        self.m, self.v, self.t = {}, {}, 0

    def step(self):
        self.t += 1
        items = [(k, t) for k, t in self.P.p.items() if t.grad is not None]
        gn = np.sqrt(sum(float((t.grad ** 2).sum()) for _, t in items))
        sc = min(1.0, self.clip / (gn + 1e-12))
        for k, t in items:
            g = t.grad * sc
            m = self.m.get(k, np.zeros_like(g)); v = self.v.get(k, np.zeros_like(g))
            m = self.b1 * m + (1 - self.b1) * g; v = self.b2 * v + (1 - self.b2) * g * g
            self.m[k], self.v[k] = m, v
            mh = m / (1 - self.b1 ** self.t); vh = v / (1 - self.b2 ** self.t)
            t.data -= (self.lr * (mh / (np.sqrt(vh) + 1e-8) + self.wd * t.data)).astype(DT)
            t.grad = None
        return gn


def gradcheck():
    """Finite-difference check of the engine (run: python autograd.py)."""
    rng = np.random.default_rng(0)
    P_ = Params(rng)
    W = P_.get("W", (4, 5)); g = P_.get("g", (5,), "ones"); b = P_.get("b", (5,), "zeros")
    E = P_.get("E", (7, 4))
    idx = rng.integers(0, 7, (2, 3))
    def f():
        x = embed(E, idx)                                   # 2,3,4
        h = layernorm(tanh(x @ W), g, b)                    # 2,3,5
        a = softmax(h @ transpose(h, (0, 2, 1)), -1)        # 2,3,3
        o = sum_(a @ h, -1)
        return bce_logits(o, (rng_fixed > 0.5).astype(DT), np.ones_like(rng_fixed))
    rng_fixed = np.random.default_rng(1).random((2, 3))
    L = f(); L.backward()
    worst = 0
    for name, t in P_.p.items():
        an = t.grad.copy()
        for _ in range(5):
            i = tuple(rng.integers(0, s) for s in t.shape)
            old = t.data[i]
            t.data[i] = old + 1e-2; lp = float(f().data)
            t.data[i] = old - 1e-2; lm = float(f().data)
            t.data[i] = old
            num = (lp - lm) / 2e-2
            worst = max(worst, abs(num - an[i]))
    print("max |numeric - analytic| =", worst)


if __name__ == "__main__":
    gradcheck()
