"""Experiment 3: goal-oriented learning-path recommendation evaluated in the ground-truth simulator."""
import os, json, argparse, time
import numpy as np
import pandas as pd
from dataset import Corpus, ROOT
from fast import WorldModel
from planning import Planner, Evaluator, LAM
from run_guidance import load_model

R = os.path.join(ROOT, "results")
POLICIES = {
    # name: (policy, world-model, optimiser, planner kwargs, theta mode, lam overrides)
    "Random": ("random", None, None, {}, None, {}),
    "Teacher rule": ("rule", None, None, {}, None, {}),
    "DKT-Greedy": ("greedy", "DKT", None, {}, "uplift", {}),
    "GUIDE-Greedy": ("greedy", "GUIDE", None, {}, "epsg", {}),
    "GUIDE+GA": ("plan", "GUIDE", "ga", {}, "epsg", {}),
    "GUIDE+PSO": ("plan", "GUIDE", "pso", {}, "epsg", {}),
    "GUIDE+GWO": ("plan", "GUIDE", "gwo", {}, "epsg", {}),
    "GUIDE-PATH (ZPD-LGWO)": ("plan", "GUIDE", "lgwo", {}, "epsg", {}),
    "w/o ZPD repair": ("plan", "GUIDE", "lgwo", dict(repair=False), "epsg", {}),
    "w/o seeded init": ("plan", "GUIDE", "lgwo", dict(seeded=False), "epsg", {}),
    "w/o EPSG prior": ("plan", "GUIDE", "lgwo", {}, "uplift", {}),
    "w/o rollout gain": ("plan", "GUIDE", "lgwo", {}, "epsg", dict(m=0.0)),
    "w/o need-readiness": ("plan", "GUIDE", "lgwo", {}, "epsg", dict(n=0.0)),
    "H=5": ("plan", "GUIDE", "lgwo", dict(H=5), "epsg", {}),
    "H=20": ("plan", "GUIDE", "lgwo", dict(H=20), "epsg", {}),
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--policies", default="Random,Teacher rule")
    ap.add_argument("--n", type=int, default=200)
    ap.add_argument("--split", default="test")
    ap.add_argument("--lam", default="")
    ap.add_argument("--tag", default="")
    a = ap.parse_args()
    C = Corpus()
    ids = np.sort(np.random.default_rng(5).choice(C.split[a.split], a.n, replace=False))
    theta = np.array(json.load(open(os.path.join(R, "epsg_theta.json")))["theta"])
    lam_extra = json.loads(a.lam) if a.lam else {}
    lp = os.path.join(R, "path_lambda.json")
    if os.path.exists(lp) and not a.lam:
        b = json.load(open(lp))["best"]; lam_extra = dict(u=b["u"], n=b["n"])
    wms = {}
    os.makedirs(os.path.join(R, "paths"), exist_ok=True)
    for name in a.policies.split(","):
        fn0 = name.replace("/", "_").replace(" ", "_").replace("(", "").replace(")", "") + a.tag
        if os.path.exists(os.path.join(R, "paths", fn0 + ".csv")):
            print("skip existing", name, flush=True); continue
        pol, wname, opt, pk, tmode, lo = POLICIES[name]
        wm = None
        if wname:
            if wname not in wms:
                wms[wname] = WorldModel(load_model(C, wname, 0), C.Qn)
            wm = wms[wname]
        th = theta.copy()
        if tmode == "uplift":
            th[:3] = 0.0; th[3] = max(th[3], 1.0)
        H = pk.pop("H", 10)
        rounds = 20 // H
        planner = Planner(C, wm, th, H=H, lam=dict(lam_extra, **lo), **pk) if wm is not None else None
        ev = Evaluator(C, ids, rounds=rounds, H=H)
        t0 = time.time()
        rows, curves = ev.run(pol, wm=wm, planner=planner, opt=opt, log_curves=True)
        sec = time.time() - t0
        df = pd.DataFrame(rows); df["policy"] = name; df["sec_per_learner"] = sec / len(ids)
        fn = name.replace("/", "_").replace(" ", "_").replace("(", "").replace(")", "") + a.tag
        df.to_csv(os.path.join(R, "paths", fn + ".csv"), index=False)
        if curves:
            grid = np.linspace(16, 400, 60)
            cv = [np.interp(grid, *np.array(c).T) for c in curves]
            json.dump(dict(grid=grid.tolist(), mean=np.mean(cv, 0).tolist()),
                      open(os.path.join(R, "paths", fn + "_curve.json"), "w"))
        print(f"{name}: Ep={df.Ep.mean():.4f}±{df.Ep.std():.4f} ret={df.Ep_ret.mean():.4f} zpd={df.zpd.mean():.3f} "
              f"opt={df.strat_opt.mean():.3f} min={df.minutes.mean():.1f} gph={df.gain_per_hour.mean():.4f} "
              f"({sec / len(ids):.2f}s/learner)", flush=True)


if __name__ == "__main__":
    main()
