"""Population-based optimisers with a common function-evaluation (FE) budget.

ZPD-LGWO (proposed) = Grey Wolf Optimizer +
  (i)   cosine non-linear convergence factor a(t) = 1 + cos(pi t / T_max)
  (ii)  rank-weighted leader fusion (alpha 6/11, beta 3/11, delta 2/11) with greedy survivor selection
  (iii) Levy-flight perturbation of the alpha wolf (Mantegna, beta = 1.5)
  (iv)  elite opposition-based learning (EOBL) triggered by stagnation
  (v)   optional problem-specific repair operator (ZPD repair for learning paths), Lamarckian write-back
  (vi)  optional seeded initialisation (SEH/PKB-guided wolves for learning paths)
All optimisers MINIMISE f.  f(X) -> F  or  f(X) -> (F, X_repaired).
"""
import math
import numpy as np


def _eval(f, X):
    out = f(X)
    if isinstance(out, tuple):
        return np.asarray(out[0], float), out[1]
    return np.asarray(out, float), X


class Tracker:
    def __init__(self, max_fe):
        self.max_fe, self.fe, self.best, self.xbest, self.curve = max_fe, 0, np.inf, None, []

    def update(self, F, X):
        self.fe += len(F)
        i = int(np.argmin(F))
        if F[i] < self.best:
            self.best, self.xbest = float(F[i]), X[i].copy()
        self.curve.append((self.fe, self.best))

    def left(self):
        return self.max_fe - self.fe


def levy(rng, size, beta=1.5):
    sig = (math.gamma(1 + beta) * math.sin(math.pi * beta / 2) /
           (math.gamma((1 + beta) / 2) * beta * 2 ** ((beta - 1) / 2))) ** (1 / beta)
    u = rng.normal(0, sig, size)
    v = rng.normal(0, 1, size)
    return u / np.abs(v) ** (1 / beta)


def _init(rng, pop, lb, ub, init=None):
    X = lb + rng.random((pop, len(lb))) * (ub - lb)
    if init is not None:
        k = min(len(init), pop // 2)
        X[:k] = init[:k]
    return X


# ----------------------------------------------------------------------------------------- GWO family
def gwo(f, lb, ub, pop=30, max_fe=15000, seed=0, variant="gwo", init=None,
        levy_flight=True, eobl=True, weighted=True, greedy=True, stall=3):
    """variant: 'gwo' (standard), 'mgwo' (quadratic decay of a), 'lgwo' (proposed)."""
    rng = np.random.default_rng(seed)
    lb, ub = np.asarray(lb, float), np.asarray(ub, float)
    D = len(lb)
    tr = Tracker(max_fe)
    X = _init(rng, pop, lb, ub, init if variant == "lgwo" else None)
    F, X = _eval(f, X); tr.update(F, X)
    T_iter = max(1, (max_fe - pop) // pop)
    t, best_prev, stagn = 0, tr.best, 0
    proposed = variant == "lgwo"
    while tr.left() >= pop:
        if proposed:
            a = 1 + math.cos(math.pi * min(t, T_iter) / T_iter)
        elif variant == "mgwo":
            a = 2 * (1 - (t / T_iter) ** 2)
        else:
            a = 2 - 2 * t / T_iter
        order = np.argsort(F)
        L = X[order[:3]]
        moves = []
        for l in range(3):
            A = 2 * a * rng.random((pop, D)) - a
            Cc = 2 * rng.random((pop, D))
            moves.append(L[l] - A * np.abs(Cc * L[l] - X))
        if proposed and weighted:
            Xn = (6 * moves[0] + 3 * moves[1] + 2 * moves[2]) / 11
        else:
            Xn = (moves[0] + moves[1] + moves[2]) / 3
        Xn = np.clip(Xn, lb, ub)
        Fn, Xn = _eval(f, Xn); tr.update(Fn, Xn)
        if proposed and greedy:
            imp = Fn < F
            X[imp], F[imp] = Xn[imp], Fn[imp]
        else:
            X, F = Xn, Fn
        if proposed:
            # (iii) Levy flight around the alpha wolf
            if levy_flight and tr.left() >= 1:
                ia = int(np.argmin(F))
                j = rng.integers(pop)
                scale = 0.01 * (X[ia] - X[j]) + 0.002 * (1 - t / T_iter) * (ub - lb)
                xl = np.clip(X[ia] + levy(rng, D) * scale, lb, ub)[None]
                fl, xl = _eval(f, xl); tr.update(fl, xl)
                if fl[0] < F[ia]:
                    X[ia], F[ia] = xl[0], fl[0]
            # (iv) elite opposition-based learning on stagnation
            stagn = stagn + 1 if tr.best >= best_prev - 1e-12 else 0
            best_prev = min(best_prev, tr.best)
            if eobl and stagn >= stall and tr.left() >= pop // 2:
                elite = X[np.argsort(F)[:max(3, pop // 5)]]
                da, db = elite.min(0), elite.max(0)
                worst = np.argsort(F)[-(pop // 2):]
                Xo = np.clip(rng.random((len(worst), D)) * (da + db) - X[worst], lb, ub)
                Fo, Xo = _eval(f, Xo); tr.update(Fo, Xo)
                imp = Fo < F[worst]
                X[worst[imp]], F[worst[imp]] = Xo[imp], Fo[imp]
                stagn = 0
        t += 1
    return tr


# ----------------------------------------------------------------------------------------- PSO
def pso(f, lb, ub, pop=30, max_fe=15000, seed=0, init=None):
    rng = np.random.default_rng(seed)
    lb, ub = np.asarray(lb, float), np.asarray(ub, float)
    D = len(lb)
    tr = Tracker(max_fe)
    X = _init(rng, pop, lb, ub)
    V = np.zeros_like(X); vmax = 0.2 * (ub - lb)
    F, X = _eval(f, X); tr.update(F, X)
    Pb, Fp = X.copy(), F.copy()
    T_iter = max(1, (max_fe - pop) // pop); t = 0
    while tr.left() >= pop:
        w = 0.9 - 0.5 * t / T_iter
        g = Pb[np.argmin(Fp)]
        V = w * V + 1.5 * rng.random((pop, D)) * (Pb - X) + 1.5 * rng.random((pop, D)) * (g - X)
        V = np.clip(V, -vmax, vmax)
        X = np.clip(X + V, lb, ub)
        F, X = _eval(f, X); tr.update(F, X)
        imp = F < Fp
        Pb[imp], Fp[imp] = X[imp], F[imp]
        t += 1
    return tr


# ----------------------------------------------------------------------------------------- GA (real coded)
def ga(f, lb, ub, pop=30, max_fe=15000, seed=0, init=None, pc=0.9, eta_c=15, eta_m=20):
    rng = np.random.default_rng(seed)
    lb, ub = np.asarray(lb, float), np.asarray(ub, float)
    D = len(lb)
    tr = Tracker(max_fe)
    X = _init(rng, pop, lb, ub)
    F, X = _eval(f, X); tr.update(F, X)
    pm = 1.0 / D
    while tr.left() >= pop - 2:
        def tour():
            i, j = rng.integers(pop, size=2)
            return X[i] if F[i] < F[j] else X[j]
        kids = []
        while len(kids) < pop - 2:
            p1, p2 = tour(), tour()
            c1, c2 = p1.copy(), p2.copy()
            if rng.random() < pc:
                u = rng.random(D)
                bq = np.where(u <= 0.5, (2 * u) ** (1 / (eta_c + 1)), (1 / (2 * (1 - u))) ** (1 / (eta_c + 1)))
                c1 = 0.5 * ((1 + bq) * p1 + (1 - bq) * p2); c2 = 0.5 * ((1 - bq) * p1 + (1 + bq) * p2)
            for c in (c1, c2):
                m = rng.random(D) < pm
                u = rng.random(D)
                dq = np.where(u < 0.5, (2 * u) ** (1 / (eta_m + 1)) - 1, 1 - (2 * (1 - u)) ** (1 / (eta_m + 1)))
                c[m] += dq[m] * (ub - lb)[m]
                kids.append(np.clip(c, lb, ub))
        K_ = np.array(kids[:pop - 2])
        Fk, K_ = _eval(f, K_); tr.update(Fk, K_)
        el = np.argsort(F)[:2]
        X = np.vstack([X[el], K_]); F = np.concatenate([F[el], Fk])
    return tr


# ----------------------------------------------------------------------------------------- DE
def de(f, lb, ub, pop=30, max_fe=15000, seed=0, init=None, Fw=0.5, CR=0.9):
    rng = np.random.default_rng(seed)
    lb, ub = np.asarray(lb, float), np.asarray(ub, float)
    D = len(lb)
    tr = Tracker(max_fe)
    X = _init(rng, pop, lb, ub)
    F, X = _eval(f, X); tr.update(F, X)
    while tr.left() >= pop:
        idx = np.array([rng.choice(np.delete(np.arange(pop), i), 3, replace=False) for i in range(pop)])
        Mv = X[idx[:, 0]] + Fw * (X[idx[:, 1]] - X[idx[:, 2]])
        cr = rng.random((pop, D)) < CR
        cr[np.arange(pop), rng.integers(D, size=pop)] = True
        U = np.clip(np.where(cr, Mv, X), lb, ub)
        Fu, U = _eval(f, U); tr.update(Fu, U)
        imp = Fu < F
        X[imp], F[imp] = U[imp], Fu[imp]
    return tr


# ----------------------------------------------------------------------------------------- WOA
def woa(f, lb, ub, pop=30, max_fe=15000, seed=0, init=None):
    rng = np.random.default_rng(seed)
    lb, ub = np.asarray(lb, float), np.asarray(ub, float)
    D = len(lb)
    tr = Tracker(max_fe)
    X = _init(rng, pop, lb, ub)
    F, X = _eval(f, X); tr.update(F, X)
    T_iter = max(1, (max_fe - pop) // pop); t = 0
    while tr.left() >= pop:
        a = 2 - 2 * t / T_iter
        best = tr.xbest
        Xn = np.empty_like(X)
        for i in range(pop):
            A = 2 * a * rng.random(D) - a; Cc = 2 * rng.random(D)
            if rng.random() < 0.5:
                if np.abs(A).mean() < 1:
                    Xn[i] = best - A * np.abs(Cc * best - X[i])
                else:
                    xr = X[rng.integers(pop)]
                    Xn[i] = xr - A * np.abs(Cc * xr - X[i])
            else:
                l = rng.uniform(-1, 1)
                Xn[i] = np.abs(best - X[i]) * np.exp(l) * np.cos(2 * np.pi * l) + best
        X = np.clip(Xn, lb, ub)
        F, X = _eval(f, X); tr.update(F, X)
        t += 1
    return tr


OPTIMIZERS = {
    "GA": ga, "PSO": pso, "DE": de, "WOA": woa,
    "GWO": lambda *a, **k: gwo(*a, variant="gwo", **k),
    "mGWO": lambda *a, **k: gwo(*a, variant="mgwo", **k),
    "LGWO": lambda *a, **k: gwo(*a, variant="lgwo", **k),
}


def random_search(f, lb, ub, pop=30, max_fe=15000, seed=0, init=None):
    rng = np.random.default_rng(seed)
    lb, ub = np.asarray(lb, float), np.asarray(ub, float)
    tr = Tracker(max_fe)
    while tr.left() > 0:
        n = min(pop, tr.left())
        X = lb + rng.random((n, len(lb))) * (ub - lb)
        F, X = _eval(f, X); tr.update(F, X)
    return tr
