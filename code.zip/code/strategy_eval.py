"""Counterfactual evaluation of explicit strategy guidance against the simulator oracle."""
import os
import numpy as np
from scipy.stats import spearmanr
from simulator import Simulator, load_states, P, K, sig, RULE_SETS, BehaviourPolicy
from dataset import ROOT


class Oracle:
    """Ground-truth expected learning gain of every strategy at every logged test step."""

    def __init__(self, C, step_stride=1):
        gt = np.load(os.path.join(ROOT, "data", "ground_truth", "test_states_before_step.npz"))
        self.ids = gt["learner_ids"]
        self.sim = Simulator(C.cur)
        st = load_states(os.path.join(ROOT, "data", "ground_truth", "final_states.npz"), self.ids)
        n, T = len(self.ids), C.T
        self.steps = np.arange(0, T, step_stride)
        G = np.zeros((n, len(self.steps), P))
        for j, t in enumerate(self.steps):
            st.theta = gt["theta"][:, t].astype(float); st.stab = gt["stab"][:, t].astype(float)
            st.mot = gt["mot"][:, t].astype(float); st.last_s = gt["last_s"][:, t].astype(int)
            G[:, j] = self.sim.expected_gain(st, C.items[self.ids, t])
        self.G = G                                                    # n, steps, P


def guidance_metrics(scores, G):
    """scores, G: (n, steps, P). Higher score = recommended."""
    s = scores.reshape(-1, P); g = G.reshape(-1, P)
    rank = np.argsort(-s, 1)
    best = g.argmax(1)
    top1 = (rank[:, 0] == best).mean()
    hit3 = (rank[:, :3] == best[:, None]).any(1).mean()
    gmin, gmax = g.min(1, keepdims=True), g.max(1, keepdims=True)
    rel = (g - gmin) / (gmax - gmin + 1e-12)
    disc = 1 / np.log2(np.arange(2, 5))
    dcg = (np.take_along_axis(rel, rank[:, :3], 1) * disc).sum(1)
    idcg = (np.sort(rel, 1)[:, ::-1][:, :3] * disc).sum(1)
    chosen = g[np.arange(len(g)), rank[:, 0]]
    regret = ((gmax[:, 0] - chosen) / (gmax[:, 0] - gmin[:, 0] + 1e-12)).mean()
    lift = chosen.mean() / g.mean()
    rho = np.nanmean([spearmanr(s[i], g[i])[0] for i in range(0, len(s), 7)])
    return dict(Top1=float(top1), Hit3=float(hit3), NDCG3=float((dcg / idcg).mean()), Regret=float(regret),
                GainLift=float(lift), Spearman=float(rho))


def rule_scores(C, ids, rng):
    """Behaviour-policy teacher rule (Elo estimate -> rule set), ties broken at random."""
    beh = BehaviourPolicy(C.cur, len(ids), rng)
    out = np.zeros((len(ids), C.T, P))
    for t in range(C.T):
        it = C.items[ids, t]
        m = sig(1.7 * (beh.est * C.cur.Qn[it]).sum(1))
        band = beh.band(m)
        sc = rng.random((len(ids), P)) * 0.1
        for b_, ss in RULE_SETS.items():
            sel = band == b_
            sc[np.ix_(sel, ss)] += 1.0
        out[:, t] = sc
        beh.update(it, C.resp[ids, t])
    return out


def context_features(C, ids):
    """Observable context used by the contextual-bandit baseline."""
    feats = np.zeros((len(ids), C.T, 4 + 6 + 1))
    beh = BehaviourPolicy(C.cur, len(ids), np.random.default_rng(0))
    acc = np.zeros(len(ids)); cnt = np.zeros(len(ids))
    from simulator import SKILL_DOMAIN
    for t in range(C.T):
        it = C.items[ids, t]
        m = sig(1.7 * (beh.est * C.cur.Qn[it]).sum(1))
        dom = np.eye(6)[SKILL_DOMAIN[C.cur.primary[it]]]
        feats[:, t, 0] = m; feats[:, t, 1] = m ** 2
        feats[:, t, 2] = acc / np.maximum(cnt, 1); feats[:, t, 3] = np.log1p(cnt)
        feats[:, t, 4:10] = dom; feats[:, t, 10] = C.cur.b[it]
        beh.update(it, C.resp[ids, t])
        acc += C.resp[ids, t]; cnt += 1
    return feats
