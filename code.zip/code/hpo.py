"""Hyper-parameter optimisation of the GUIDE encoder with LGWO vs. GWO vs. random search (equal FE budget)."""
import os, json, time, sys
import numpy as np
from dataset import Corpus, ROOT
from train_kt import train_model, predict, seh_auc
from sklearn.metrics import roc_auc_score
from optimizers import gwo, random_search

D_CH, H_CH = [32, 48, 64, 96], [1, 2, 4]
SPACE = ["d", "heads", "lr", "dropout", "lam_g", "wd"]


def decode(x):
    x = np.clip(x, 0, 0.9999)
    return dict(d=D_CH[int(x[0] * 4)], heads=H_CH[int(x[1] * 3)], lr=float(10 ** (-3 + x[2])),
                dropout=float(0.3 * x[3]), lam_g=float(0.1 + 1.4 * x[4]), wd=float(10 ** (-6 + 3 * x[5])))


def main(budget=20, pop=5, epochs=6, n_sub=800):
    C = Corpus()
    rng = np.random.default_rng(11)
    sub = rng.choice(C.split["train"], n_sub, replace=False)
    va = C.split["valid"]
    cache, log = {}, []

    def fitness(X, who):
        F = []
        for x in X:
            hp = decode(x)
            key = json.dumps(hp, sort_keys=True)
            if key not in cache:
                t0 = time.time()
                m, hist, _ = train_model(C, "GUIDE", seed=0, hp=hp, epochs=epochs, patience=10, train_ids=sub, verbose=False)
                pv = predict(m, C, va)
                auc = roc_auc_score(C.resp[va].ravel(), pv["kt"].ravel()); sa = seh_auc(pv["seh"], C, va)
                cache[key] = -(auc + 0.5 * sa)
                print(f"[{who}] {hp} AUC={auc:.4f} SEH={sa:.4f} ({time.time() - t0:.0f}s)", flush=True)
            log.append(dict(optimizer=who, hp=hp, fitness=cache[key]))
            F.append(cache[key])
        return np.array(F)

    out = {}
    lb, ub = np.zeros(6), np.ones(6)
    for name, fn in [("LGWO", lambda f: gwo(f, lb, ub, pop=pop, max_fe=budget, seed=3, variant="lgwo")),
                     ("GWO", lambda f: gwo(f, lb, ub, pop=pop, max_fe=budget, seed=3, variant="gwo")),
                     ("RandomSearch", lambda f: random_search(f, lb, ub, pop=pop, max_fe=budget, seed=3))]:
        tr = fn(lambda X: fitness(X, name))
        out[name] = dict(best_fitness=tr.best, best_hp=decode(tr.xbest), curve=tr.curve)
        print(name, out[name]["best_hp"], tr.best, flush=True)
    out["log"] = log
    out["default_fitness"] = float(fitness(np.array([[0.5, 0.34, 0.477, 0.333, 0.286, 0.333]]), "default")[0])
    json.dump(out, open(os.path.join(ROOT, "results", "hpo.json"), "w"), indent=1)
    best = min(["LGWO", "GWO", "RandomSearch"], key=lambda k: out[k]["best_fitness"])
    json.dump(out["LGWO"]["best_hp"], open(os.path.join(ROOT, "results", "guide_best_hp.json"), "w"), indent=1)
    print("best optimiser:", best)


if __name__ == "__main__":
    main()
