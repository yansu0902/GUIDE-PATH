"""Assemble the manuscript: numeric citations, references, pandoc -> .docx (native Word equations), table styling."""
import os, re, subprocess, json
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from dataset import ROOT

PAPER = os.path.join(ROOT, "paper")
REFS = {
    "huang2023": "Huang, X., Zou, D., Cheng, G., Chen, X., & Xie, H. (2023). Trends, research issues and applications of artificial intelligence in language education. *Educational Technology & Society*, 26(1), 112–131. https://doi.org/10.30191/ETS.202301_26(1).0009",
    "kartal2024": "Kartal, G., & Yeşilyurt, Y. E. (2024). A bibliometric analysis of artificial intelligence in L2 teaching and applied linguistics between 1995 and 2022. *ReCALL*, 36(3), 359–375. https://doi.org/10.1017/S0958344024000077",
    "lee2024": "Lee, H., & Lee, J. H. (2024). The effects of AI-guided individualized language learning: A meta-analysis. *Language Learning & Technology*, 28(2), 134–162. https://hdl.handle.net/10125/73575",
    "kasneci2023": "Kasneci, E., Sessler, K., Küchemann, S., Bannert, M., Dementieva, D., Fischer, F., et al. (2023). ChatGPT for good? On opportunities and challenges of large language models for education. *Learning and Individual Differences*, 103, 102274. https://doi.org/10.1016/j.lindif.2023.102274",
    "kohnke2023": "Kohnke, L., Moorhouse, B. L., & Zou, D. (2023). ChatGPT for language teaching and learning. *RELC Journal*, 54(2), 537–550. https://doi.org/10.1177/00336882231162868",
    "jeon2023": "Jeon, J., & Lee, S. (2023). Large language models in education: A focus on the complementary relationship between human teachers and ChatGPT. *Education and Information Technologies*, 28(12), 15873–15892. https://doi.org/10.1007/s10639-023-11834-1",
    "bhutoria2022": "Bhutoria, A. (2022). Personalized education and artificial intelligence in the United States, China, and India: A systematic review using a Human-In-The-Loop model. *Computers and Education: Artificial Intelligence*, 3, 100068. https://doi.org/10.1016/j.caeai.2022.100068",
    "bayly2024": "Bayly-Castaneda, K., Ramirez-Montoya, M.-S., & Morita-Alexander, A. (2024). Crafting personalized learning paths with AI for lifelong learning: A systematic literature review. *Frontiers in Education*, 9, 1424386. https://doi.org/10.3389/feduc.2024.1424386",
    "abdelrahman2023": "Abdelrahman, G., Wang, Q., & Nunes, B. P. (2023). Knowledge tracing: A survey. *ACM Computing Surveys*, 55(11), Article 224. https://doi.org/10.1145/3569576",
    "shen2024": "Shen, S., Liu, Q., Huang, Z., Zheng, Y., Yin, M., Wang, M., & Chen, E. (2024). A survey of knowledge tracing: Models, variants, and applications. *IEEE Transactions on Learning Technologies*, 17, 1898–1919. https://doi.org/10.1109/TLT.2024.3383325",
    "liu2022pykt": "Liu, Z., Liu, Q., Chen, J., Huang, S., Tang, J., & Luo, W. (2022). pyKT: A Python library to benchmark deep learning based knowledge tracing models. In *Advances in Neural Information Processing Systems 35 (NeurIPS 2022), Datasets and Benchmarks Track*.",
    "liu2023simplekt": "Liu, Z., Liu, Q., Chen, J., Huang, S., & Luo, W. (2023). simpleKT: A simple but tough-to-beat baseline for knowledge tracing. In *Proceedings of the 11th International Conference on Learning Representations (ICLR 2023)*.",
    "yin2023": "Yin, Y., Dai, L., Huang, Z., Shen, S., Wang, F., Liu, Q., Chen, E., & Li, X. (2023). Tracing knowledge instead of patterns: Stable knowledge tracing with diagnostic transformer. In *Proceedings of the ACM Web Conference 2023 (WWW '23)* (pp. 855–864). https://doi.org/10.1145/3543507.3583255",
    "lu2022cmkt": "Lu, Y., Chen, P., Pian, Y., & Zheng, V. W. (2022). CMKT: Concept map driven knowledge tracing. *IEEE Transactions on Learning Technologies*, 15(4), 467–480. https://doi.org/10.1109/TLT.2022.3196355",
    "brody2022": "Brody, S., Alon, U., & Yahav, E. (2022). How attentive are graph attention networks? In *Proceedings of the 10th International Conference on Learning Representations (ICLR 2022)*.",
    "chen2023src": "Chen, X., Shen, J., Xia, W., Jin, J., Song, Y., Zhang, W., Liu, W., Zhu, M., Tang, R., Dong, K., Xia, D., & Yu, Y. (2023). Set-to-sequence ranking-based concept-aware learning path recommendation. *Proceedings of the AAAI Conference on Artificial Intelligence*, 37(4), 5027–5035. https://doi.org/10.1609/aaai.v37i4.25630",
    "li2023gehrl": "Li, Q., Xia, W., Yin, L., Shen, J., Rui, R., Zhang, W., Chen, X., Tang, R., & Yu, Y. (2023). Graph enhanced hierarchical reinforcement learning for goal-oriented learning path recommendation. In *Proceedings of the 32nd ACM International Conference on Information and Knowledge Management (CIKM '23)* (pp. 1318–1327). https://doi.org/10.1145/3583780.3614897",
    "kaser2024": "Käser, T., & Alexandron, G. (2024). Simulated learners in educational technology: A systematic literature review and a Turing-like test. *International Journal of Artificial Intelligence in Education*. https://doi.org/10.1007/s40593-023-00337-2",
    "saito2022": "Saito, Y., & Joachims, T. (2022). Off-policy evaluation for large action spaces via embeddings. In *Proceedings of the 39th International Conference on Machine Learning (ICML 2022)*, PMLR 162 (pp. 19089–19122).",
    "khosravi2022": "Khosravi, H., Buckingham Shum, S., Chen, G., Conati, C., Tsai, Y.-S., Kay, J., Knight, S., Martinez-Maldonado, R., Sadiq, S., & Gašević, D. (2022). Explainable artificial intelligence in education. *Computers and Education: Artificial Intelligence*, 3, 100074. https://doi.org/10.1016/j.caeai.2022.100074",
    "kim2022": "Kim, S. K., & Webb, S. (2022). The effects of spaced practice on second language learning: A meta-analysis. *Language Learning*, 72(1), 269–319. https://doi.org/10.1111/lang.12479",
    "brown2023": "Brown, D., Liu, Q., & Norouzian, R. (2023). Effectiveness of written corrective feedback in developing L2 accuracy: A Bayesian meta-analysis. *Language Teaching Research*. https://doi.org/10.1177/13621688221147374",
    "xuan2022": "Xuan, Q., Cheung, A., & Liu, J. (2022). How effective is task-based language teaching to enhance second language learning? A technical comment on Bryfonski and McKay (2019). *Language Teaching Research*. https://doi.org/10.1177/13621688221131127",
    "zhang2023": "Zhang, S., & Hasim, Z. (2023). Gamification in EFL/ESL instruction: A systematic review of empirical research. *Frontiers in Psychology*, 13, 1030790. https://doi.org/10.3389/fpsyg.2022.1030790",
    "barbieri2023": "Barbieri, C. A., Miller-Cotto, D., Clerjuste, S. N., & Chawla, K. (2023). A meta-analysis of the worked examples effect on mathematics performance. *Educational Psychology Review*, 35, Article 11. https://doi.org/10.1007/s10648-023-09745-1",
    "makhadmeh2024": "Makhadmeh, S. N., Al-Betar, M. A., Doush, I. A., Awadallah, M. A., Kassaymeh, S., Mirjalili, S., & Zitar, R. A. (2024). Recent advances in Grey Wolf Optimizer, its versions and applications: Review. *IEEE Access*, 12, 22991–23028. https://doi.org/10.1109/ACCESS.2023.3304889",
    "liu2024gwo": "Liu, Y., As'arry, A., Hassan, M. K., Hairuddin, A. A., & Mohamad, H. (2024). Review of the grey wolf optimization algorithm: Variants and applications. *Neural Computing and Applications*, 36, 2713–2735. https://doi.org/10.1007/s00521-023-09202-8",
    "wu2023": "Wu, L., Wu, J., & Meng, Z. (2023). Enhancing grey wolf optimizer with Lévy flight for engineering applications. *IEEE Access*, 11, 74865–74897. https://doi.org/10.1109/ACCESS.2023.3295242",
}

HEADER = """---
title: "GUIDE-PATH: An AI-Driven Framework for Personalized English Education via Explicit Pedagogical Strategy Guidance"
---

**Author One**^1^\\*, **Author Two**^2^, **Author Three**^1^

^1^ Department / School, University, City, Country
^2^ Department / School, University, City, Country
\\* Corresponding author: name@institution.edu

"""


def cite(text):
    order = []
    def num(k):
        if k not in order:
            order.append(k)
        return order.index(k) + 1
    def repl(m):
        keys = [k.strip().lstrip("@") for k in m.group(1).split(";")]
        ns = sorted(num(k) for k in keys)
        parts, i = [], 0
        while i < len(ns):
            j = i
            while j + 1 < len(ns) and ns[j + 1] == ns[j] + 1:
                j += 1
            parts.append(f"{ns[i]}–{ns[j]}" if j - i >= 2 else ", ".join(str(x) for x in ns[i:j + 1]))
            i = j + 1
        return "[" + ", ".join(parts) + "]"
    out = re.sub(r"\[(@[^\]]+)\]", repl, text)
    return out, order


def style_doc(path):
    d = Document(path)
    allst = {s.name: s for s in d.styles if s.type == 1 or s.type == 3}
    class _S(dict):
        def __getitem__(self, k): return allst[k]
    st = allst
    for name in ["Normal", "Body Text", "First Paragraph", "Compact"]:
        if name in st:
            s = st[name]; s.font.name = "Times New Roman"; s.font.size = Pt(11)
            s.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
            s.paragraph_format.space_after = Pt(5); s.paragraph_format.line_spacing = 1.15
            if name in ["Body Text", "First Paragraph"]:
                s.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    for name, size in [("Title", 17), ("Heading 2", 13.5), ("Heading 3", 11.5)]:
        if name in st:
            s = st[name]; s.font.name = "Times New Roman"; s.font.size = Pt(size); s.font.bold = True
            s.font.color.rgb = RGBColor(0x10, 0x10, 0x10)
            s.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
            s.paragraph_format.space_before = Pt(12 if name != "Heading 3" else 8); s.paragraph_format.space_after = Pt(5)
            s.paragraph_format.keep_with_next = True
    for name in ["Image Caption", "Table Caption", "Caption"]:
        if name in st:
            s = st[name]; s.font.name = "Times New Roman"; s.font.size = Pt(9.5); s.font.italic = False
            s.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY; s.paragraph_format.space_after = Pt(8)
    if "Source Code" in st:
        st["Source Code"].font.size = Pt(8.5)
    for sec in d.sections:
        sec.left_margin = sec.right_margin = Cm(2.2); sec.top_margin = sec.bottom_margin = Cm(2.2)
    # three-line tables
    for t in d.tables:
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        tbl = t._tbl
        tblPr = tbl.tblPr
        borders = OxmlElement("w:tblBorders")
        for edge, val, sz in [("top", "single", 10), ("bottom", "single", 10), ("insideH", "nil", 0),
                              ("insideV", "nil", 0), ("left", "nil", 0), ("right", "nil", 0)]:
            el = OxmlElement(f"w:{edge}"); el.set(qn("w:val"), val)
            if sz:
                el.set(qn("w:sz"), str(sz)); el.set(qn("w:color"), "000000")
            borders.append(el)
        for old in tblPr.findall(qn("w:tblBorders")):
            tblPr.remove(old)
        tblPr.append(borders)
        for ri, row in enumerate(t.rows):
            for cell in row.cells:
                if ri == 0:
                    tcPr = cell._tc.get_or_add_tcPr()
                    b = OxmlElement("w:tcBorders"); bt = OxmlElement("w:bottom")
                    bt.set(qn("w:val"), "single"); bt.set(qn("w:sz"), "6"); bt.set(qn("w:color"), "000000")
                    b.append(bt); tcPr.append(b)
                for p in cell.paragraphs:
                    p.paragraph_format.space_after = Pt(1); p.paragraph_format.space_before = Pt(1)
                    p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.LEFT
                    for r in p.runs:
                        r.font.size = Pt(8.5); r.font.name = "Times New Roman"
                        if ri == 0:
                            r.font.bold = True
    d.save(path)


def main():
    parts = [open(os.path.join(PAPER, f), encoding="utf-8").read() for f in
             ["sec_abstract.md", "sec_front.md", "sec_setup.md", "sec_results.md", "sec_end.md"]]
    body = "\n\n".join(parts)
    body, order = cite(body)
    missing = [k for k in order if k not in REFS]
    assert not missing, missing
    refs = "\n\n## References\n\n" + "\n\n".join(f"[{i + 1}] {REFS[k]}" for i, k in enumerate(order)) + "\n"
    md = HEADER + body + refs
    mdp = os.path.join(PAPER, "GUIDE-PATH_manuscript.md")
    open(mdp, "w", encoding="utf-8").write(md)
    out = os.path.join(PAPER, "GUIDE-PATH_manuscript.docx")
    subprocess.run(["pandoc", mdp, "-o", out, "--resource-path", PAPER, "-f", "markdown+tex_math_dollars+pipe_tables+implicit_figures+superscript"],
                   check=True, cwd=PAPER)
    style_doc(out)
    print("references:", len(order), "unused:", [k for k in REFS if k not in order])
    print("written", out)


if __name__ == "__main__":
    main()
