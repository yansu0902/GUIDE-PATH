"""Experiment 2: explicit strategy guidance vs. the simulator oracle (+ off-policy value on held-out logs)."""
import os, json, glob
import numpy as np
from sklearn.linear_model import LogisticRegression
from dataset import Corpus, ROOT
from models import KTNet, CONFIGS
from train_kt import predict, DEFAULT_HP
from strategy_eval import Oracle, guidance_metrics, rule_scores, context_features
from guidance import (Calibrator, fused_scores, pkb_features, prev3_from_logs, snips_residual,
                      CAL_LB, CAL_UB, DEFAULT_THETA, PKB_TEXT)
from optimizers import gwo, random_search
from simulator import P, SKILL_DOMAIN, sig

R = os.path.join(ROOT, "results")


def load_model(C, name, seed):
    tag = f"{name}_s{seed}"
    meta = json.load(open(os.path.join(R, "models", tag + ".json")))
    hp = meta["hp"]
    base = name.replace("-noSEH", "").replace("-noIPW", "").replace("-default", "")
    m = KTNet(C.cur.n, CONFIGS[base], d=hp["d"], heads=hp["heads"], dropout=hp["dropout"], seed=seed)
    m.Pm.load(dict(np.load(os.path.join(R, "models", tag + ".npz"))))
    return m


def available(name):
    return sorted(int(f.split("_s")[-1].split(".")[0]) for f in glob.glob(os.path.join(R, "models", f"{name}_s*.npz")))


def calibrate(cal, method, seed=0, fe=300):
    if method == "default":
        return DEFAULT_THETA.copy(), cal.value(DEFAULT_THETA), None
    if method == "LGWO":
        tr = gwo(cal.objective, CAL_LB, CAL_UB, pop=10, max_fe=fe, seed=seed, variant="lgwo")
    elif method == "GWO":
        tr = gwo(cal.objective, CAL_LB, CAL_UB, pop=10, max_fe=fe, seed=seed, variant="gwo")
    else:
        tr = random_search(cal.objective, CAL_LB, CAL_UB, pop=10, max_fe=fe, seed=seed)
    return tr.xbest, -tr.best, tr.curve


def main():
    C = Corpus()
    O = Oracle(C)
    te, va = O.ids, C.split["valid"]
    out = {"policies": {}, "pkb": PKB_TEXT}
    rng = np.random.default_rng(0)
    # reference baseline for SNIPS residual: GUIDE seed-0 delayed-outcome base model
    gref = load_model(C, "GUIDE", 0)
    pref = predict(gref, C, te, all_strats=True)
    base_te = sig(pref["seh_base"])
    logged, prop, y, mask = C.strat[te], C.prop[te], C.yg[te], C.mg[te]

    def record(name, scores, seed=0):
        a = scores.argmax(-1)
        met = guidance_metrics(scores, O.G)
        met["OPE"] = snips_residual(a, logged, prop, y, base_te, mask)[0]
        out["policies"].setdefault(name, []).append(dict(seed=seed, **met))
        print(name, seed, {k: round(v, 4) for k, v in met.items()}, flush=True)

    # ---------------- non-learned baselines
    record("Random", rng.random(O.G.shape))
    freq = np.bincount(C.strat[C.split["train"]].ravel(), minlength=P)
    record("Popularity", np.broadcast_to(freq + 1e-3 * rng.random(P), O.G.shape).copy())
    record("Teacher rule (logging policy)", rule_scores(C, te, np.random.default_rng(1)))
    # ---------------- contextual bandit (IPW logistic per strategy)
    Ftr = context_features(C, C.split["train"]); Fte = context_features(C, te)
    trn = C.split["train"]
    sc = np.zeros(O.G.shape)
    for p in range(P):
        sel = (C.strat[trn] == p) & (C.mg[trn] > 0)
        lr = LogisticRegression(max_iter=1000)
        lr.fit(Ftr[sel], C.yg[trn][sel], sample_weight=C.ipw[trn][sel])
        sc[..., p] = lr.predict_proba(Fte.reshape(-1, Fte.shape[-1]))[:, 1].reshape(O.G.shape[:2])
    record("Contextual IPW-LR bandit", sc)
    # ---------------- learned uplift heads of every encoder
    names = ["DKT", "SAKT", "AKT", "GAT-KT", "GUIDE", "GUIDE-noPMGA", "GUIDE-noFiLM", "GUIDE-noDecay",
             "GUIDE-noRel", "GUIDE-noSEH", "GUIDE-noIPW", "GUIDE-default"]
    theta_store = {}
    for nm in names:
        for s in available(nm):
            m = load_model(C, nm, s)
            pt = predict(m, C, te, all_strats=True)
            if nm == "GUIDE-noSEH":
                record("GUIDE w/o SEH (immediate-correctness ranking)", pt["kt_all"], s)
                continue
            record(f"{nm} [learned uplift only]", pt["seh_all"], s)
            if nm.startswith("GUIDE") or nm in ["DKT", "SAKT", "AKT", "GAT-KT"]:
                pv = predict(m, C, va, all_strats=True)
                cal = Calibrator(C, va, pv)
                th, v, curve = calibrate(cal, "LGWO", seed=s)
                m_hat = sig(pt["kt_neutral"])
                dom, rep = pkb_features(m_hat, SKILL_DOMAIN[C.cur.primary[C.items[te]]], prev3_from_logs(C.strat[te]))
                lab = "GUIDE-PATH EPSG (PKB + uplift, LGWO-calibrated)" if nm == "GUIDE" else f"{nm} + EPSG"
                record(lab, fused_scores(th, m_hat, dom, rep, pt["seh_all"]), s)
                if nm == "GUIDE":
                    theta_store[s] = dict(theta=th.tolist(), val_value=v, curve=curve)
                    th0 = th.copy(); th0[3] = 0.0
                    record("PKB only (calibrated, no learned uplift)", fused_scores(th0, m_hat, dom, rep, pt["seh_all"]), s)
                    for meth in ["GWO", "RandomSearch", "default"]:
                        thm, vm, cm = calibrate(cal, meth, seed=s)
                        record(f"EPSG calibrated by {meth}", fused_scores(thm, m_hat, dom, rep, pt["seh_all"]), s)
                        theta_store.setdefault(f"{s}_{meth}", dict(theta=thm.tolist(), val_value=vm, curve=cm))
                    if s == 0:
                        # interpretability: recommended strategy share by (true mastery band, domain)
                        gt = np.load(os.path.join(ROOT, "data", "ground_truth", "test_states_before_step.npz"))
                        th_true = gt["theta"]
                        Qn = C.cur.Qn[C.items[te]]
                        mt = sig(1.7 * (th_true * Qn).sum(-1))
                        band = np.digitize(mt, [0.4, 0.7])
                        rec = fused_scores(th, m_hat, dom, rep, pt["seh_all"]).argmax(-1)
                        orc = O.G.argmax(-1)
                        tab = {"model": np.zeros((3, P)).tolist(), "oracle": np.zeros((3, P)).tolist(),
                               "model_dom": np.zeros((6, P)).tolist(), "oracle_dom": np.zeros((6, P)).tolist()}
                        dd = SKILL_DOMAIN[C.cur.primary[C.items[te]]]
                        for b_ in range(3):
                            tab["model"][b_] = np.bincount(rec[band == b_], minlength=P).tolist()
                            tab["oracle"][b_] = np.bincount(orc[band == b_], minlength=P).tolist()
                        for d_ in range(6):
                            tab["model_dom"][d_] = np.bincount(rec[dd == d_], minlength=P).tolist()
                            tab["oracle_dom"][d_] = np.bincount(orc[dd == d_], minlength=P).tolist()
                        out["interpretability"] = tab
                        att = m.graph()[1]
                        out["pmga_attention"] = att.data.mean(1).tolist()          # (P+1, K, K)
    out["epsg_theta"] = theta_store
    json.dump(out, open(os.path.join(R, "guidance.json"), "w"))
    json.dump(theta_store.get(0, {"theta": DEFAULT_THETA.tolist()}), open(os.path.join(R, "epsg_theta.json"), "w"), indent=1)
    # summary table
    print("\nSUMMARY (mean over seeds)")
    for k, v in out["policies"].items():
        arr = {m: np.mean([x[m] for x in v]) for m in v[0] if m != "seed"}
        print(f"{k:55s}", {m: round(a, 4) for m, a in arr.items()})


if __name__ == "__main__":
    main()
