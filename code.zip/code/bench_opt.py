"""Benchmark of ZPD-LGWO's core optimiser (LGWO) on 10 shifted classical functions (D = 30)."""
import os, json, time, sys
import numpy as np
from scipy.stats import mannwhitneyu, friedmanchisquare
from optimizers import OPTIMIZERS
from dataset import ROOT

D, RUNS, POP, FE = 30, 30, 30, 15000


def make_funcs(seed=7):
    rng = np.random.default_rng(seed)
    def sh(lo, hi):
        return rng.uniform(0.5 * lo, 0.5 * hi, D) * 0.8
    o = {}
    F = {}
    o[1] = sh(-100, 100); F["F1 Sphere"] = (lambda X, o=o[1]: ((X - o) ** 2).sum(1), -100, 100)
    o[2] = sh(-10, 10); F["F2 Schwefel 2.22"] = (lambda X, o=o[2]: np.abs(X - o).sum(1) + np.prod(np.abs(X - o), 1), -10, 10)
    o[3] = sh(-100, 100); F["F3 Schwefel 1.2"] = (lambda X, o=o[3]: (np.cumsum(X - o, 1) ** 2).sum(1), -100, 100)
    o[4] = sh(-100, 100); F["F4 Schwefel 2.21"] = (lambda X, o=o[4]: np.abs(X - o).max(1), -100, 100)
    o[5] = sh(-30, 30); F["F5 Rosenbrock"] = (lambda X, o=o[5]: (100 * ((X - o + 1)[:, 1:] - (X - o + 1)[:, :-1] ** 2) ** 2 + ((X - o + 1)[:, :-1] - 1) ** 2).sum(1), -30, 30)
    o[6] = sh(-100, 100); F["F6 Step"] = (lambda X, o=o[6]: (np.floor(X - o + 0.5) ** 2).sum(1), -100, 100)
    o[7] = sh(-1.28, 1.28); F["F7 Quartic+noise"] = (lambda X, o=o[7]: (np.arange(1, D + 1) * (X - o) ** 4).sum(1) + np.random.default_rng(0).random(len(X)), -1.28, 1.28)
    o[8] = sh(-5.12, 5.12); F["F8 Rastrigin"] = (lambda X, o=o[8]: ((X - o) ** 2 - 10 * np.cos(2 * np.pi * (X - o)) + 10).sum(1), -5.12, 5.12)
    o[9] = sh(-32, 32); F["F9 Ackley"] = (lambda X, o=o[9]: -20 * np.exp(-0.2 * np.sqrt(((X - o) ** 2).mean(1))) - np.exp(np.cos(2 * np.pi * (X - o)).mean(1)) + 20 + np.e, -32, 32)
    o[10] = sh(-600, 600); F["F10 Griewank"] = (lambda X, o=o[10]: ((X - o) ** 2).sum(1) / 4000 - np.prod(np.cos((X - o) / np.sqrt(np.arange(1, D + 1))), 1) + 1, -600, 600)
    return F


def main():
    funcs = make_funcs()
    algs = ["GA", "PSO", "DE", "WOA", "GWO", "mGWO", "LGWO"]
    res, curves = {}, {}
    t0 = time.time()
    for fn, (f, lo, hi) in funcs.items():
        res[fn], curves[fn] = {}, {}
        for a in algs:
            vals, cv = [], []
            for r in range(RUNS):
                tr = OPTIMIZERS[a](f, np.full(D, lo), np.full(D, hi), pop=POP, max_fe=FE, seed=1000 + r)
                vals.append(tr.best)
                fe, b = np.array(tr.curve).T
                cv.append(np.interp(np.linspace(POP, FE, 100), fe, b))
            res[fn][a] = vals
            curves[fn][a] = np.mean(cv, 0).tolist()
        print(fn, {a: f"{np.mean(v):.3e}" for a, v in res[fn].items()}, f"{time.time() - t0:.0f}s", flush=True)
    # statistics
    stats = {}
    for fn in funcs:
        stats[fn] = {}
        for a in algs:
            if a == "LGWO":
                continue
            try:
                p = mannwhitneyu(res[fn]["LGWO"], res[fn][a], alternative="two-sided").pvalue
            except ValueError:
                p = 1.0
            sign = "+" if (np.median(res[fn]["LGWO"]) < np.median(res[fn][a]) and p < 0.05) else (
                "-" if (np.median(res[fn]["LGWO"]) > np.median(res[fn][a]) and p < 0.05) else "=")
            stats[fn][a] = dict(p=float(p), sign=sign)
    means = np.array([[np.mean(res[fn][a]) for a in algs] for fn in funcs])
    ranks = np.array([np.argsort(np.argsort(m)) + 1 for m in means])
    fr = friedmanchisquare(*[means[:, j] for j in range(len(algs))])
    out = dict(algs=algs, D=D, runs=RUNS, pop=POP, max_fe=FE, results=res, stats=stats,
               mean_rank=dict(zip(algs, ranks.mean(0).tolist())), friedman=dict(stat=float(fr.statistic), p=float(fr.pvalue)),
               curves=curves)
    json.dump(out, open(os.path.join(ROOT, "results", "benchmark_optimizers.json"), "w"))
    print("mean ranks", out["mean_rank"], "friedman", out["friedman"])


if __name__ == "__main__":
    main()
