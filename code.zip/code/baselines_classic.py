"""Classical knowledge-tracing baselines: BKT (grid-search MLE per skill) and PFA (+ strategy one-hot)."""
import os, json, itertools, time
import numpy as np
from sklearn.linear_model import LogisticRegression
from dataset import Corpus, ROOT
from train_kt import kt_metrics
from simulator import K, P


def bkt_run(C, ids, params):
    """Forward BKT for all skills. params: (K,4) [L0, T, G, S]. Returns P(correct) (n,T)."""
    Q = C.cur.Q[C.items[ids]]                                   # n,T,K
    n, T = len(ids), C.T
    L = np.repeat(params[None, :, 0], n, 0)
    out = np.zeros((n, T))
    for t in range(T):
        m = Q[:, t] > 0
        pc = L * (1 - params[:, 3]) + (1 - L) * params[:, 2]
        out[:, t] = (pc * m).sum(1) / m.sum(1)
        r = C.resp[ids, t][:, None]
        post = np.where(r == 1, L * (1 - params[:, 3]) / pc, L * params[:, 3] / (1 - pc))
        post = post + (1 - post) * params[:, 1]
        L = np.where(m, post, L)
    return out


def bkt_fit(C, ids):
    grid = np.array(list(itertools.product([0.1, 0.3, 0.5, 0.7], [0.02, 0.05, 0.1, 0.2, 0.3],
                                           [0.1, 0.2, 0.3], [0.05, 0.1, 0.2])))
    Q = C.cur.Q[C.items[ids]]
    n, T, G = len(ids), C.T, len(grid)
    best = np.zeros((K, 4))
    for k in range(K):
        L = np.repeat(grid[None, :, 0], n, 0)
        ll = np.zeros(G)
        for t in range(T):
            m = Q[:, t, k] > 0
            if not m.any():
                continue
            pc = L[m] * (1 - grid[:, 3]) + (1 - L[m]) * grid[:, 2]
            r = C.resp[ids[m], t][:, None]
            ll += (r * np.log(pc + 1e-9) + (1 - r) * np.log(1 - pc + 1e-9)).sum(0)
            post = np.where(r == 1, L[m] * (1 - grid[:, 3]) / pc, L[m] * grid[:, 3] / (1 - pc))
            L[m] = post + (1 - post) * grid[:, 1]
        best[k] = grid[ll.argmax()]
    return best


def pfa_features(C, ids):
    it = C.items[ids]; Q = C.cur.Q[it] > 0
    n, T = it.shape
    succ = np.zeros((n, K)); fail = np.zeros((n, K))
    X = np.zeros((n, T, 3 * K + P), np.float32)
    for t in range(T):
        q = Q[:, t]
        X[:, t, :K] = q; X[:, t, K:2 * K] = q * np.log1p(succ); X[:, t, 2 * K:3 * K] = q * np.log1p(fail)
        X[np.arange(n), t, 3 * K + C.strat[ids, t]] = 1
        r = C.resp[ids, t][:, None]
        succ += q * r; fail += q * (1 - r)
    return X.reshape(n * T, -1)


def main():
    C = Corpus()
    tr, te = C.split["train"], C.split["test"]
    res = {}
    t0 = time.time()
    prm = bkt_fit(C, tr)
    p = bkt_run(C, te, prm)
    res["BKT"] = kt_metrics(p, C.resp[te]); res["BKT"]["train_sec"] = time.time() - t0
    t0 = time.time()
    lr = LogisticRegression(max_iter=2000, C=1.0)
    lr.fit(pfa_features(C, tr), C.resp[tr].ravel())
    p = lr.predict_proba(pfa_features(C, te))[:, 1].reshape(len(te), C.T)
    res["PFA"] = kt_metrics(p, C.resp[te]); res["PFA"]["train_sec"] = time.time() - t0
    print(json.dumps(res, indent=1))
    json.dump(res, open(os.path.join(ROOT, "results", "classic_kt.json"), "w"), indent=1)


if __name__ == "__main__":
    main()
