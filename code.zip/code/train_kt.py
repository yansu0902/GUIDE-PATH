"""Training / evaluation utilities for all deep models (knowledge tracing + SEH)."""
import os, json, time, sys, argparse
import numpy as np
from sklearn.metrics import roc_auc_score
from dataset import Corpus, ROOT
from models import KTNet, CONFIGS
from autograd import AdamW

DEFAULT_HP = dict(d=64, heads=2, lr=3e-3, wd=1e-5, dropout=0.1, lam_g=0.5, batch=64)


def sig(x):
    return 1 / (1 + np.exp(-x))


def build(C, name, hp, seed):
    return KTNet(C.cur.n, CONFIGS[name.replace("-noSEH", "").replace("-noIPW", "")], d=hp["d"], heads=hp["heads"],
                 dropout=hp["dropout"], seed=seed)


def predict(model, C, ids, all_strats=False, bs=100):
    model.train = False
    out = {"kt": [], "seh": [], "seh_all": [], "kt_all": [], "kt_neutral": [], "seh_base": []}
    for i in range(0, len(ids), bs):
        b = C.batch(ids[i:i + bs])
        o = model.forward(b, all_strats=all_strats)
        out["kt"].append(sig(o["kt"].data))
        if all_strats:
            for k in ["seh_all", "kt_all", "kt_neutral", "seh_base"]:
                out[k].append(o[k])
        else:
            out["seh"].append(sig(o["seh_log"].data))
    model.train = True
    return {k: np.concatenate(v) for k, v in out.items() if v}


def kt_metrics(p, y):
    p, y = p.ravel(), y.ravel()
    eps = 1e-7
    return dict(AUC=float(roc_auc_score(y, p)), ACC=float(((p > 0.5) == y).mean()),
                RMSE=float(np.sqrt(((p - y) ** 2).mean())),
                BCE=float(-(y * np.log(p + eps) + (1 - y) * np.log(1 - p + eps)).mean()))


def seh_auc(p, C, ids):
    m = C.mg[ids] > 0
    return float(roc_auc_score(C.yg[ids][m], p[m]))


def train_model(C, name, seed=0, hp=None, epochs=20, patience=4, train_ids=None, verbose=True, max_minutes=None):
    hp = dict(DEFAULT_HP, **(hp or {}))
    lam_g = 0.0 if name.endswith("-noSEH") else hp["lam_g"]
    ipw = not name.endswith("-noIPW")
    rng = np.random.default_rng(seed)
    model = build(C, name, hp, seed)
    opt = AdamW(model.Pm, lr=hp["lr"], wd=hp["wd"])
    tr = C.split["train"] if train_ids is None else train_ids
    va = C.split["valid"]
    best, best_state, bad, hist = -1, None, 0, []
    t0 = time.time()
    for ep in range(epochs):
        perm = rng.permutation(tr)
        losses = []
        for i in range(0, len(perm), hp["batch"]):
            b = C.batch(perm[i:i + hp["batch"]], ipw=ipw)
            L, _ = model.loss(b, lam_g=lam_g)
            L.backward(); opt.step()
            losses.append(float(L.data))
        pv = predict(model, C, va)
        auc = roc_auc_score(C.resp[va].ravel(), pv["kt"].ravel())
        sa = seh_auc(pv["seh"], C, va)
        score = auc + (0.5 * sa if lam_g > 0 else 0)
        hist.append(dict(epoch=ep + 1, loss=float(np.mean(losses)), val_auc=float(auc), val_seh_auc=float(sa),
                         sec=time.time() - t0))
        if verbose:
            print(f"[{name} s{seed}] ep{ep + 1} loss={np.mean(losses):.4f} valAUC={auc:.4f} valSEH={sa:.4f} "
                  f"t={time.time() - t0:.0f}s", flush=True)
        if score > best + 1e-4:
            best, best_state, bad = score, model.Pm.state(), 0
        else:
            bad += 1
            if bad >= patience:
                break
        if max_minutes and (time.time() - t0) / 60 > max_minutes:
            break
    model.Pm.load(best_state)
    return model, hist, time.time() - t0


def evaluate(model, C, ids):
    pr = predict(model, C, ids)
    res = kt_metrics(pr["kt"], C.resp[ids])
    res["SEH_AUC"] = seh_auc(pr["seh"], C, ids)
    return res, pr


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--models", default="GUIDE")
    ap.add_argument("--seeds", default="0")
    ap.add_argument("--hp", default="")
    ap.add_argument("--tag", default="")
    a = ap.parse_args()
    C = Corpus()
    hp = json.load(open(a.hp)) if a.hp else {}
    os.makedirs(os.path.join(ROOT, "results", "models"), exist_ok=True)
    for name in a.models.split(","):
        for seed in [int(s) for s in a.seeds.split(",")]:
            if os.path.exists(os.path.join(ROOT, "results", "models", f"{name}{a.tag}_s{seed}.json")):
                print("skip existing", name, seed, flush=True); continue
            model, hist, sec = train_model(C, name, seed, hp)
            res, pr = evaluate(model, C, C.split["test"])
            res.update(model=name + a.tag, seed=seed, train_sec=sec, epochs=len(hist), n_params=model.Pm.n_params())
            print("TEST", json.dumps(res), flush=True)
            tag = f"{name}{a.tag}_s{seed}"
            np.savez_compressed(os.path.join(ROOT, "results", "models", tag + ".npz"), **model.Pm.state())
            json.dump(dict(result=res, history=hist, hp=dict(DEFAULT_HP, **hp)),
                      open(os.path.join(ROOT, "results", "models", tag + ".json"), "w"), indent=1)
