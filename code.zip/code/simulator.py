"""
GUIDE-PATH -- Cognitively grounded English-learner simulator (EngPath-Sim).

The simulator encodes well-documented pedagogical regularities as aptitude-treatment
interactions (ATI) so that the *true* learning effect of every pedagogical strategy is
known.  It is used (i) to generate the logged interaction corpus (raw data) and
(ii) as the ground-truth environment for counterfactual evaluation of strategy guidance
and learning-path recommendation.

Latent learner state per skill k: ability theta_k (logit), baseline theta0_k (floor
for forgetting), memory stability stab_k; per learner: learning rate eta, forgetting
rate phi, motivation, anxiety, sociability and strategy affinities.
"""
import numpy as np

# ----------------------------------------------------------------------------------
# Static curriculum: 24 CEFR-aligned English sub-skills in 6 domains
# ----------------------------------------------------------------------------------
DOMAINS = ["Vocabulary", "Grammar", "Reading", "Listening", "Speaking", "Writing"]
SKILLS = [
    ("V1", "High-frequency lexis", 0), ("V2", "Academic vocabulary", 0),
    ("V3", "Collocations & phrasal verbs", 0), ("V4", "Word formation", 0),
    ("G1", "Tense & aspect", 1), ("G2", "Articles & determiners", 1),
    ("G3", "Clause structure", 1), ("G4", "Modality & conditionals", 1),
    ("R1", "Literal comprehension", 2), ("R2", "Inferential comprehension", 2),
    ("R3", "Text structure & cohesion", 2), ("R4", "Reading fluency", 2),
    ("L1", "Word recognition in speech", 3), ("L2", "Gist listening", 3),
    ("L3", "Detail listening", 3), ("L4", "Connected-speech decoding", 3),
    ("S1", "Pronunciation & intelligibility", 4), ("S2", "Oral fluency", 4),
    ("S3", "Interactional competence", 4), ("S4", "Pragmatics & register", 4),
    ("W1", "Sentence-level accuracy", 5), ("W2", "Paragraph organisation", 5),
    ("W3", "Argumentative writing", 5), ("W4", "Lexico-grammatical range", 5),
]
SKILL_CODES = [s[0] for s in SKILLS]
K = len(SKILLS)
SKILL_DOMAIN = np.array([s[2] for s in SKILLS])
_idx = {c: i for i, c in enumerate(SKILL_CODES)}
PREREQ_EDGES = [  # (prerequisite -> dependent)
    ("V1", "V2"), ("V1", "V3"), ("V4", "V2"), ("V1", "R1"), ("V1", "L2"),
    ("V2", "R2"), ("V2", "W3"), ("V3", "S2"), ("V3", "W4"),
    ("G1", "G4"), ("G1", "W1"), ("G2", "W1"), ("G1", "S2"), ("G3", "R3"),
    ("G3", "W2"), ("G3", "W4"), ("G4", "S4"),
    ("R1", "R2"), ("R1", "R4"), ("R3", "R2"), ("R3", "W2"), ("R2", "W3"),
    ("L1", "L2"), ("L1", "L3"), ("L1", "L4"), ("L2", "S3"), ("L4", "S3"),
    ("S1", "S2"), ("S2", "S3"), ("S3", "S4"),
    ("W1", "W2"), ("W2", "W3"), ("W4", "W3"),
]
PREREQ = np.zeros((K, K))  # PREREQ[j, i] = 1 if j is a prerequisite of i
for a, b in PREREQ_EDGES:
    PREREQ[_idx[a], _idx[b]] = 1.0


def _depth():
    d = np.zeros(K)
    for _ in range(K):
        for j, i in zip(*np.nonzero(PREREQ)):
            d[i] = max(d[i], d[j] + 1)
    return d


SKILL_DEPTH = _depth()

# ----------------------------------------------------------------------------------
# Pedagogical strategies (explicit, interpretable action space)
# ----------------------------------------------------------------------------------
STRATEGIES = [
    ("EI", "Explicit instruction"), ("WE", "Worked examples"),
    ("SP", "Scaffolded practice"), ("RP", "Retrieval / spaced practice"),
    ("CF", "Corrective feedback"), ("TB", "Task-based communicative task"),
    ("CL", "Collaborative / peer learning"), ("GD", "Gamified drill"),
]
P = len(STRATEGIES)
STRAT_CODES = [s[0] for s in STRATEGIES]
# domain efficacy  E[p, domain]   (V, G, R, L, S, W)
EFFICACY = np.array([
    [1.0, 1.2, 0.8, 0.7, 0.6, 0.9],
    [0.8, 1.3, 0.9, 0.6, 0.5, 1.2],
    [1.0, 1.0, 1.1, 1.0, 0.9, 1.1],
    [1.3, 1.0, 0.9, 0.9, 0.7, 0.8],
    [0.7, 1.3, 0.6, 0.8, 1.2, 1.3],
    [0.8, 0.7, 0.9, 1.3, 1.4, 1.0],
    [0.8, 0.8, 1.0, 1.0, 1.2, 1.1],
    [1.4, 0.9, 0.6, 0.8, 0.6, 0.6],
])
SUPPORT = np.array([0.5, 0.7, 0.4, -0.3, 0.0, -0.3, 0.2, 0.2])   # immediate logit support
TIME_MULT = np.array([1.6, 1.3, 1.2, 0.8, 1.0, 1.8, 1.5, 0.7])   # time cost multiplier
TRANSFER = np.array([0.10, 0.10, 0.12, 0.05, 0.10, 0.25, 0.18, 0.06])
STAB_GAIN = np.array([1.08, 1.08, 1.10, 1.35, 1.08, 1.10, 1.08, 1.05])
BASE_GAIN = 0.30


def sig(x):
    return 1.0 / (1.0 + np.exp(-x))


def mastery_curve(m):
    """f_p(m): expertise-reversal / ZPD-shaped dependence of each strategy on mastery m.
    m: (...,) array -> (..., P)"""
    m = np.asarray(m)[..., None]
    out = np.concatenate([
        1.4 * (1 - m) ** 1.5 + 0.10,                                # EI
        1.5 * (1 - m) ** 2.0 + 0.10,                                # WE
        1.0 * np.exp(-((m - 0.5) / 0.25) ** 2) + 0.20,              # SP
        1.2 * m ** 1.2 + 0.05,                                      # RP
        0.8 * np.ones_like(m),                                      # CF (error-driven, see below)
        1.2 * sig(8 * (m - 0.55)) + 0.05,                           # TB
        0.75 * np.ones_like(m),                                     # CL
        1.0 * (1 - m) + 0.20,                                       # GD
    ], axis=-1)
    return out


class Curriculum:
    """Item bank + Q-matrix."""

    def __init__(self, rng, items_per_skill=30):
        rows = []
        for k in range(K):
            dom = SKILL_DOMAIN[k]
            same_dom = [j for j in range(K) if SKILL_DOMAIN[j] == dom and j != k]
            neigh = list(np.nonzero(PREREQ[:, k])[0]) + list(np.nonzero(PREREQ[k])[0])
            for _ in range(items_per_skill):
                sk = [k]
                if rng.random() < 0.5:
                    pool = neigh if (neigh and rng.random() < 0.6) else same_dom
                    sk.append(int(rng.choice(pool)))
                if rng.random() < 0.15:
                    sk.append(int(rng.choice(same_dom)))
                sk = sorted(set(sk))
                b = float(np.clip(rng.normal(-0.3 + 0.15 * SKILL_DEPTH[k], 1.0), -3, 3))
                a = float(np.exp(rng.normal(0, 0.2)))
                tmin = float(rng.uniform(1.0, 4.0))
                rows.append((k, sk, b, a, tmin))
        self.n = len(rows)
        self.primary = np.array([r[0] for r in rows])
        self.skills = [r[1] for r in rows]
        self.b = np.array([r[2] for r in rows])
        self.a = np.array([r[3] for r in rows])
        self.tmin = np.array([r[4] for r in rows])
        self.Q = np.zeros((self.n, K))
        for i, sk in enumerate(self.skills):
            self.Q[i, sk] = 1.0
        self.Qn = self.Q / self.Q.sum(1, keepdims=True)
        self.by_skill = [np.nonzero(self.primary == k)[0] for k in range(K)]


def load_curriculum(path):
    """Rebuild the item bank from data/ground_truth/curriculum.npz."""
    d = np.load(path)
    cur = Curriculum.__new__(Curriculum)
    cur.primary, cur.b, cur.a, cur.tmin, cur.Q = d["primary"], d["b"], d["a"], d["tmin"], d["Q"]
    cur.n = len(cur.b)
    cur.skills = [list(np.nonzero(q)[0]) for q in cur.Q]
    cur.Qn = cur.Q / cur.Q.sum(1, keepdims=True)
    cur.by_skill = [np.nonzero(cur.primary == k)[0] for k in range(K)]
    return cur


def load_states(path, ids):
    d = np.load(path)
    st = LearnerState.__new__(LearnerState)
    for k in d.files:
        st.__dict__[k] = d[k][ids].copy()
    st.n = len(ids)
    return st


class LearnerState:
    """Vectorised state for a population of learners."""

    def __init__(self, n, rng):
        self.n = n
        lvl = rng.choice(4, size=n, p=[0.25, 0.35, 0.28, 0.12])          # A1, A2, B1, B2
        g = -1.6 + 0.85 * lvl + rng.normal(0, 0.3, n)
        dom_off = rng.normal(0, 0.45, (n, len(DOMAINS)))
        theta = g[:, None] + dom_off[:, SKILL_DOMAIN] - 0.25 * SKILL_DEPTH[None] + rng.normal(0, 0.3, (n, K))
        self.cefr = lvl
        self.theta = theta
        self.theta0 = theta.copy()
        self.stab = np.ones((n, K))
        self.eta = np.exp(rng.normal(0, 0.3, n))
        self.phi = np.exp(rng.normal(np.log(0.04), 0.4, n))
        self.anx = rng.beta(2, 3, n)
        self.soc = rng.beta(2, 2, n)
        self.mot = rng.beta(3, 2, n)
        self.aff = np.exp(rng.normal(0, 0.3, (n, P)))
        self.last_s = -np.ones((n, 3), dtype=int)
        self.clock = np.zeros(n)                                             # hours

    def copy(self, idx=None):
        new = LearnerState.__new__(LearnerState)
        for k, v in self.__dict__.items():
            if isinstance(v, np.ndarray):
                new.__dict__[k] = (v[idx] if idx is not None else v).copy()
            else:
                new.__dict__[k] = v
        new.n = len(new.theta)
        return new


class Simulator:
    def __init__(self, cur: Curriculum):
        self.cur = cur

    # ---------------- observation model ----------------
    def p_correct(self, st, items, strats, rows=None):
        rows = np.arange(st.n) if rows is None else rows
        th = (st.theta[rows] * self.cur.Qn[items]).sum(1)
        logit = 1.7 * self.cur.a[items] * (th - self.cur.b[items]) + SUPPORT[strats] + 0.3 * (st.mot[rows] - 0.5)
        return sig(logit)

    def p_correct_nosupport(self, st, items, rows=None):
        rows = np.arange(st.n) if rows is None else rows
        th = (st.theta[rows] * self.cur.Qn[items]).sum(1)
        return sig(1.7 * self.cur.a[items] * (th - self.cur.b[items]))

    # ---------------- learning model ----------------
    def gain_matrix(self, st, items, rows=None):
        """Deterministic per-skill gain factor for every strategy and both outcomes.
        returns G (n, P, K) for r=1 and r=0 (before noise)"""
        rows = np.arange(st.n) if rows is None else rows
        n = len(rows)
        Qi = self.cur.Q[items]                                   # n,K
        m = sig(1.7 * st.theta[rows])                            # n,K mastery
        f = mastery_curve(m)                                     # n,K,P
        f = np.transpose(f, (0, 2, 1))                           # n,P,K
        eff = EFFICACY[:, SKILL_DOMAIN][None]                    # 1,P,K
        p0 = self.p_correct_nosupport(st, items, rows)           # n
        z = 0.25 + 0.75 * np.exp(-((p0 - 0.65) / 0.25) ** 2)     # ZPD factor
        pm = sig(1.7 * st.theta[rows])
        pre_cnt = PREREQ.sum(0)
        pre_m = (pm @ PREREQ) / np.maximum(pre_cnt, 1)
        pf = np.where(pre_cnt > 0, 0.35 + 0.65 * np.minimum(1, pre_m / 0.65), 1.0)  # n,K
        aff = st.aff[rows].copy()                                # n,P
        aff[:, 5] *= (1 - 0.6 * st.anx[rows])                    # TB hurt by anxiety
        aff[:, 6] *= (1 - 0.3 * st.anx[rows]) * (0.7 + 0.6 * st.soc[rows])
        nov = np.ones((n, P))
        ls = st.last_s[rows]
        same3 = (ls[:, 0] == ls[:, 1]) & (ls[:, 1] == ls[:, 2]) & (ls[:, 0] >= 0)
        nov[same3, ls[same3, 0]] = 0.75                          # novelty / habituation
        scale = (BASE_GAIN * st.eta[rows] * (0.5 + st.mot[rows]) * z / np.sqrt(Qi.sum(1)))[:, None, None]
        G = scale * f * eff * pf[:, None, :] * (aff * nov)[:, :, None] * Qi[:, None, :]
        Gc, Gw = G.copy(), G.copy()
        Gc[:, 4] *= 0.5                                          # CF: error-driven
        Gw[:, 4] *= 1.6
        return Gc, Gw

    def expected_gain(self, st, items, rows=None):
        """Oracle expected direct learning gain (logits, mean over item skills) per strategy (n,P)."""
        rows = np.arange(st.n) if rows is None else rows
        Gc, Gw = self.gain_matrix(st, items, rows)
        pc = np.stack([self.p_correct(st, items, np.full(len(rows), p), rows) for p in range(P)], 1)
        G = pc[:, :, None] * Gc + (1 - pc[:, :, None]) * Gw
        Qi = self.cur.Q[items]
        return (G.sum(2) / Qi.sum(1, keepdims=True))

    def forget(self, st, dt_hours, rows=None):
        rows = np.arange(st.n) if rows is None else rows
        days = dt_hours / 24.0
        decay = np.exp(-st.phi[rows, None] * days[:, None] / st.stab[rows])
        st.theta[rows] = st.theta0[rows] + (st.theta[rows] - st.theta0[rows]) * decay

    def step(self, st, items, strats, dt_hours, rng, rows=None):
        """Advance learners `rows` by one interaction. Returns (responses, p, minutes)."""
        rows = np.arange(st.n) if rows is None else rows
        n = len(rows)
        self.forget(st, dt_hours, rows)
        st.clock[rows] += dt_hours
        p = self.p_correct(st, items, strats, rows)
        r = (rng.random(n) < p).astype(int)
        Gc, Gw = self.gain_matrix(st, items, rows)
        ar = np.arange(n)
        G = np.where(r[:, None] == 1, Gc[ar, strats], Gw[ar, strats])      # n,K
        G = G * np.exp(rng.normal(0, 0.2, (n, 1)) - 0.02)
        trans = (G @ PREREQ) * TRANSFER[strats][:, None]                  # transfer to dependent skills
        st.theta[rows] += G + trans
        Qi = self.cur.Q[items] > 0
        st.stab[rows] = np.where(Qi, np.minimum(st.stab[rows] * STAB_GAIN[strats][:, None], 4.0), st.stab[rows])
        mot = st.mot[rows]
        mot = mot + 0.04 * (strats == 7) * (1 - mot) + 0.01 * r - 0.02 * (1 - r)
        mot = mot - 0.03 * (strats == 5) * st.anx[rows]
        ls = st.last_s[rows]
        mot = mot - 0.02 * ((ls[:, 0] == strats) & (ls[:, 1] == strats))
        st.mot[rows] = np.clip(mot, 0.05, 1.0)
        st.last_s[rows] = np.concatenate([strats[:, None], ls[:, :2]], 1)
        minutes = self.cur.tmin[items] * TIME_MULT[strats]
        return r, p, minutes

    def probe_mastery(self, st, skills, rows=None):
        """Success probability on a median-difficulty probe (b = skill median) per skill."""
        rows = np.arange(st.n) if rows is None else rows
        bmed = np.array([np.median(self.cur.b[self.cur.by_skill[k]]) for k in range(K)])
        return sig(1.7 * (st.theta[rows][:, skills] - bmed[skills]))


# ----------------------------------------------------------------------------------
# Behaviour (logging) policy of the existing platform: Elo-based teacher heuristic
# ----------------------------------------------------------------------------------
RULE_SETS = {0: [0, 1, 7], 1: [2, 4, 6], 2: [3, 5, 6]}


class BehaviourPolicy:
    def __init__(self, cur, n, rng, eps=0.5):
        self.cur, self.rng, self.eps = cur, rng, eps
        self.est = np.zeros((n, K))
        self.cnt = np.zeros((n, K))

    def band(self, m):
        return np.where(m < 0.4, 0, np.where(m < 0.7, 1, 2))

    def act(self):
        n = self.est.shape[0]
        rng = self.rng
        dom_m = np.stack([self.est[:, SKILL_DOMAIN == d].mean(1) for d in range(len(DOMAINS))], 1)
        weak_dom = dom_m.argmin(1)
        u = rng.random(n)
        skill = np.empty(n, dtype=int)
        for i in range(n):
            if u[i] < 0.4:
                cand = np.nonzero(SKILL_DOMAIN == weak_dom[i])[0]
                skill[i] = rng.choice(cand)
            elif u[i] < 0.7 or self.cnt[i].sum() == 0:
                skill[i] = rng.integers(K)
            else:
                prac = np.nonzero(self.cnt[i] > 0)[0]
                skill[i] = rng.choice(prac)
        items = np.empty(n, dtype=int)
        for i in range(n):
            pool = self.cur.by_skill[skill[i]]
            ph = sig(1.7 * (self.est[i, skill[i]] - self.cur.b[pool]))
            sc = -np.abs(ph - 0.7) / 0.1 + rng.gumbel(size=len(pool))
            items[i] = pool[sc.argmax()]
        m = sig(1.7 * (self.est * self.cur.Qn[items]).sum(1))
        bands = self.band(m)
        prop = np.full((n, P), self.eps / P)
        for b, ss in RULE_SETS.items():
            sel = bands == b
            prop[np.ix_(sel, ss)] += (1 - self.eps) / len(ss)
        cum = prop.cumsum(1)
        strats = (rng.random((n, 1)) > cum).sum(1)
        strats = np.minimum(strats, P - 1)
        return items, strats, prop[np.arange(n), strats], prop

    def update(self, items, r):
        Qn = self.cur.Qn[items]
        p = sig(1.7 * ((self.est * Qn).sum(1) - self.cur.b[items]))
        self.est += 0.4 * (r - p)[:, None] * (Qn > 0)
        self.cnt += (Qn > 0)


def session_gaps(rng, n, T):
    """Elapsed hours before each interaction: short gaps inside sessions, longer between."""
    gaps = np.zeros((n, T))
    for i in range(n):
        t = 0
        while t < T:
            L = int(rng.poisson(10)) + 4
            gap = rng.exponential(40.0) + 6.0 if t > 0 else 0.0
            gaps[i, t] = gap
            for j in range(t + 1, min(T, t + L)):
                gaps[i, j] = rng.uniform(0.03, 0.08)
            t += L
    return gaps
