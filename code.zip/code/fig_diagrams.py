"""Figure 1 (technical architecture) and Figure 2 (methodology flow) for the GUIDE-PATH manuscript."""
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from dataset import ROOT

FIG = os.path.join(ROOT, "figures")
BLUE, ORANGE, AQUA, YELLOW, MAGENTA, GREEN, VIOLET, RED = ("#2a78d6", "#eb6834", "#1baf7a", "#eda100",
                                                         "#e87ba4", "#008300", "#6250d6", "#e34948")
INK, INK2, GRID = "#0b0b0b", "#52514e", "#d9d8d4"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9})


def tint(hex_, a=0.13):
    h = hex_.lstrip("#"); r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
    return (1 - a + a * r / 255, 1 - a + a * g / 255, 1 - a + a * b / 255)


def box(ax, x, y, w, h, title, lines, color, fs=8.2, tfs=9.2):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.008,rounding_size=0.012",
                                fc=tint(color), ec=color, lw=1.4))
    ax.text(x + w / 2, y + h - 0.018, title, ha="center", va="top", fontsize=tfs, weight="bold", color=INK)
    ax.text(x + w / 2, y + h - 0.052, "\n".join(lines), ha="center", va="top", fontsize=fs, color=INK2,
            linespacing=1.35)


def arrow(ax, p, q, color=INK2, style="-|>", lw=1.3, rad=0.0, ls="-"):
    ax.add_patch(FancyArrowPatch(p, q, arrowstyle=style, mutation_scale=11, lw=lw, color=color,
                                 connectionstyle=f"arc3,rad={rad}", linestyle=ls))


def band(ax, y, h, label, color):
    ax.add_patch(FancyBboxPatch((0.008, y), 0.984, h, boxstyle="round,pad=0.004,rounding_size=0.01",
                                fc="none", ec=color, lw=1.0, ls=(0, (4, 3))))
    ax.text(0.016, y + h - 0.012, label, ha="left", va="top", fontsize=9.5, weight="bold", color=color)


def poly(ax, pts, color=INK2, lw=1.3, ls="-", head=True):
    xs, ys = zip(*pts)
    ax.plot(xs[:-1] if head else xs, ys[:-1] if head else ys, color=color, lw=lw, ls=ls, solid_capstyle="round")
    if head:
        arrow(ax, pts[-2], pts[-1], color=color, lw=lw, ls=ls)


def architecture():
    fig = plt.figure(figsize=(15, 9.0))
    ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    # ---- band A: GUIDE encoder
    band(ax, 0.665, 0.325, "(A) GUIDE — Graph-Unified Instructional-strategy-Driven Encoder", BLUE)
    yA, hA = 0.725, 0.215
    box(ax, 0.02, yA, 0.135, hA, "Learner logs", ["item q_t, skills S(q_t)", "strategy s_t (8 types)",
                                                 "response r_t, time τ_t", "logging propensity π_b"], INK2)
    box(ax, 0.175, yA, 0.17, hA, "HSSG", ["Heterogeneous Skill–Strategy Graph", "24 CEFR sub-skills",
                                         "prerequisite / dependent /", "peer / self edges",
                                         "+ 8 strategy nodes + neutral"], GREEN)
    box(ax, 0.365, yA, 0.20, hA, "PMGA", ["Pedagogy-Modulated Graph Attention",
                                         "FiLM: (1+γ_p)⊙W h_i + β_p",
                                         "GATv2 score + edge-type bias",
                                         "+ strategy × edge-type bias B[p,τ]",
                                         "→ Z^(p) ∈ R^(24×d), p = 0..8"], BLUE)
    box(ax, 0.585, yA, 0.17, hA, "Interaction encoder", ["x_t = M̃_t Z^(s_t) + μ_q M̃_t V",
                                                        "      + E_sr[s_t, r_t] + E_r[r_t]",
                                                        "q_t = M̃_t Z^(∅) + μ_q M̃_t V",
                                                        "(Rasch item variation)"], VIOLET)
    box(ax, 0.775, yA, 0.205, hA, "FRTA", ["Forgetting- & Relation-aware", "Temporal Attention",
                                          "QKᵀ/√d − softplus(θ_h)·log(1+Δτ)",
                                          "      + β_h · m_tᵀ Â m_j",
                                          "→ knowledge state h_t"], ORANGE)
    for x0, x1 in [(0.155, 0.175), (0.345, 0.365), (0.565, 0.585), (0.755, 0.775)]:
        arrow(ax, (x0, yA + hA / 2), (x1, yA + hA / 2))
    arrow(ax, (0.465, yA), (0.84, yA), color=ORANGE, rad=0.22, ls="--")
    ax.text(0.66, 0.69, "learned relation matrix Â (mean PMGA attention)", fontsize=8, color=ORANGE, ha="center")
    # ---- band B
    band(ax, 0.335, 0.31, "(B) Prediction heads and Explicit Pedagogical Strategy Guidance (EPSG)", MAGENTA)
    yB, hB = 0.415, 0.175
    box(ax, 0.02, yB, 0.20, hB, "Response head", ["p̂(r_t=1) = σ(MLP[h_t ; q_t + E_s])",
                                                 "strategy dropout → neutral slot",
                                                 "→ mastery estimate m̂"], ORANGE)
    box(ax, 0.24, yB, 0.235, hB, "Strategy-Efficacy Head (SEH)", ["delayed outcome = b(h_t, q_next, Δτ)",
                                                                 "      + δ̃_(s_t)(h_t)   (centred uplift)",
                                                                 "IPW-weighted BCE (π_unif / π_b)",
                                                                 "→ uplift δ̃_p for all 8 strategies"], AQUA)
    box(ax, 0.495, yB, 0.215, hB, "Pedagogical Knowledge Base", ["R1 expertise reversal   R2 ZPD",
                                                                "R3 desirable difficulties",
                                                                "R4 domain evidence   R5 variety",
                                                                "(qualitative, literature-based)"], GREEN)
    box(ax, 0.755, yB, 0.225, hB, "EPSG fusion", ["score_p = w_m·band_p + w_d·dom_p",
                                                 "      − w_v·rep_p + κ·z(δ̃_p)",
                                                 "θ = (w_m, w_d, w_v, κ, t1, t2)",
                                                 "LGWO-calibrated on SNIPS value"], MAGENTA)
    # h_t bus to heads
    poly(ax, [(0.877, yA), (0.877, 0.655), (0.12, 0.655), (0.12, yB + hB)], head=True)
    poly(ax, [(0.357, 0.655), (0.357, yB + hB)], head=True)
    ax.text(0.60, 0.659, "h_t", fontsize=9, color=INK2, ha="center", style="italic")
    # heads + PKB bus into fusion
    for xc in (0.12, 0.357, 0.60):
        ax.plot([xc, xc], [yB, 0.375], color=INK2, lw=1.3)
    poly(ax, [(0.12, 0.375), (0.733, 0.375), (0.733, yB + hB / 2), (0.755, yB + hB / 2)], head=True)
    ax.text(0.42, 0.355, "m̂ (bands), δ̃ (uplift), rule indicators", fontsize=8, color=INK2, ha="center")
    # ---- band C: PATH
    band(ax, 0.012, 0.305, "(C) PATH — Pedagogy-Aware Trajectory Hunter (ZPD-LGWO model-predictive planner)", RED)
    yC, hC = 0.05, 0.19
    box(ax, 0.02, yC, 0.20, hC, "Goal & candidate pool", ["goal domain (weakest observed)",
                                                         "targets + graph prerequisites",
                                                         "need × readiness NR_k (HSSG)"], GREEN)
    box(ax, 0.24, yC, 0.27, hC, "ZPD-LGWO search", ["wolf = random keys (item, strategy) × H",
                                                   "a(t) = 1 + cos(πt/T), rank-weighted leaders",
                                                   "Lévy-flight α wolf, elite OBL on stagnation",
                                                   "ZPD repair (p̂ ∈ [0.5, 0.8]), seeded wolves"], RED)
    box(ax, 0.53, yC, 0.21, hC, "World-model rollout", ["GUIDE fast inference",
                                                       "soft responses p̂ appended",
                                                       "J = ΔM + λ_u F̃ + λ_n NR",
                                                       "     − λ_z ZPD − λ_t time"], BLUE)
    box(ax, 0.76, yC, 0.22, hC, "Personalised path", ["⟨(item, strategy)⟩ × H", "executed; responses observed",
                                                     "→ appended to logs, re-plan", "(MPC, 2 × 10 steps)"], VIOLET)
    arrow(ax, (0.22, yC + hC / 2), (0.24, yC + hC / 2))
    arrow(ax, (0.51, yC + hC * 0.62), (0.53, yC + hC * 0.62)); arrow(ax, (0.53, yC + hC * 0.38), (0.51, yC + hC * 0.38))
    ax.text(0.52, yC + hC * 0.70, "X", fontsize=7, color=INK2, ha="center"); ax.text(0.52, yC + hC * 0.22, "J", fontsize=7, color=INK2, ha="center")
    arrow(ax, (0.74, yC + hC / 2), (0.76, yC + hC / 2))
    poly(ax, [(0.868, yB), (0.868, 0.272), (0.375, 0.272), (0.375, yC + hC)], color=MAGENTA, head=True)
    ax.text(0.62, 0.279, "fused strategy scores + SEH/PKB-seeded wolves", fontsize=8, color=MAGENTA, ha="center")
    fig.savefig(os.path.join(FIG, "Fig1_architecture.png"), dpi=300)
    plt.close(fig)


def flow():
    fig = plt.figure(figsize=(9.2, 11.6))
    ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    steps = [
        ("1  Learner simulation & logging", ["24 sub-skills, prerequisite DAG, 8 strategies, ATI effects,",
                                            "forgetting; Elo-teacher behaviour policy (ε = 0.5) → 300k logs"], INK2),
        ("2  Pre-processing", ["learner-level split 70/10/20; Q-matrix; delayed outcomes (≤30 steps);",
                               "elapsed-time & relation tensors; inverse-propensity weights"], INK2),
        ("3  HSSG construction", ["typed edges: self / prerequisite / dependent / peer;",
                                  "strategy nodes condition message passing"], GREEN),
        ("4  LGWO hyper-parameter search", ["d, heads, lr, dropout, λ_g, weight decay;",
                                           "fitness = val AUC + 0.5·val SEH-AUC (equal budget vs GWO, RS)"], RED),
        ("5  GUIDE training", ["L = BCE(response) + λ_g · IPW-BCE(delayed outcome);",
                              "AdamW, early stopping on validation score"], BLUE),
        ("6  EPSG calibration", ["fuse PKB rules with centred uplift δ̃;",
                                 "LGWO maximises SNIPS value on validation logs"], MAGENTA),
        ("7  PATH planning (ZPD-LGWO, MPC)", ["random-key wolves, ZPD repair, seeded init;",
                                              "GUIDE rollouts score each candidate path"], RED),
        ("8  Evaluation", ["(i) KT accuracy  (ii) guidance vs oracle  (iii) learning gains in simulator",
                           "ablations, sensitivity, optimiser benchmark, statistical tests"], VIOLET),
    ]
    n = len(steps); top = 0.965; h = 0.078; gap = (top - 0.03 - n * h) / (n - 1)
    ys = []
    for i, (t, l, c) in enumerate(steps):
        y = top - h - i * (h + gap); ys.append(y)
        box(ax, 0.15, y, 0.70, h, t, l, c, fs=8.6, tfs=10)
        if i:
            arrow(ax, (0.5, ys[i - 1]), (0.5, y + h))
    # loops on the right
    arrow(ax, (0.855, ys[4] + h / 2), (0.855, ys[3] + h / 2), color=RED, rad=0.55, ls="--")
    ax.text(0.935, (ys[3] + ys[4]) / 2 + h / 2, "fitness of\nnext wolf\npositions", fontsize=7.5, color=RED,
            ha="center", va="center")
    arrow(ax, (0.855, ys[7] + h / 2), (0.855, ys[6] + h / 2), color=INK2, rad=0.55, ls="--")
    ax.text(0.935, (ys[6] + ys[7]) / 2 + h / 2, "observe\n& re-plan\n(MPC)", fontsize=7.5, color=INK2,
            ha="center", va="center")
    # phase brackets on the left
    phases = [("DATA", 0, 1, INK2), ("MODEL", 2, 4, BLUE), ("GUIDANCE &\nPLANNING", 5, 6, MAGENTA),
              ("EVALUATION", 7, 7, VIOLET)]
    for lab, i0, i1, c in phases:
        y0, y1 = ys[i1] + 0.004, ys[i0] + h - 0.004
        ax.plot([0.12, 0.11, 0.11, 0.12], [y1, y1, y0, y0], color=c, lw=1.6)
        ax.text(0.085, (y0 + y1) / 2, lab, rotation=90, ha="center", va="center", fontsize=8.5, weight="bold", color=c)
    fig.savefig(os.path.join(FIG, "Fig2_methodology_flow.png"), dpi=300)
    plt.close(fig)


if __name__ == "__main__":
    os.makedirs(FIG, exist_ok=True)
    architecture(); flow()
