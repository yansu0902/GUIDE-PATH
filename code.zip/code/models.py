"""GUIDE encoder (PMGA + FRTA) and deep knowledge-tracing baselines in one configurable network.

All deep models share the same input embeddings and the two prediction heads
(immediate-response head and Strategy-Efficacy Head, SEH) so that differences come from the
encoders.  Every model receives the logged strategy as an input (additive embedding).
"""
import numpy as np
import autograd as ag
from autograd import Tensor, Params
from simulator import K, P
from dataset import skill_graph

NTYPE = 5
CONFIGS = {
    # name           encoder graph   decay       relation strat_mod
    "DKT":      dict(encoder="lstm", graph="none", decay="none", relation=False, strat_mod=False),
    "SAKT":     dict(encoder="attn", graph="none", decay="none", relation=False, strat_mod=False),
    "AKT":      dict(encoder="attn", graph="none", decay="position", relation=False, strat_mod=False),
    "GAT-KT":   dict(encoder="attn", graph="gat", decay="none", relation=False, strat_mod=False),
    "GUIDE":    dict(encoder="attn", graph="pmga", decay="elapsed", relation=True, strat_mod=True),
    # ablations of GUIDE
    "GUIDE-noPMGA":   dict(encoder="attn", graph="none", decay="elapsed", relation=False, strat_mod=False),
    "GUIDE-noFiLM":   dict(encoder="attn", graph="gat", decay="elapsed", relation=True, strat_mod=False),
    "GUIDE-noDecay":  dict(encoder="attn", graph="pmga", decay="none", relation=True, strat_mod=True),
    "GUIDE-noRel":    dict(encoder="attn", graph="pmga", decay="elapsed", relation=False, strat_mod=True),
}


class KTNet:
    def __init__(self, n_items, cfg, d=64, heads=2, glayers=2, dropout=0.1, seed=0):
        self.cfg = dict(cfg)
        self.d, self.h, self.gl, self.dp = d, heads, glayers, dropout
        self.rng = np.random.default_rng(seed)
        self.Pm = Params(self.rng)
        self.n_items = n_items
        self.etype = skill_graph()
        self.gmask = np.where(self.etype > 0, 0.0, -1e9).astype(np.float32)
        self.onehot_type = np.eye(NTYPE, dtype=np.float32)[self.etype]           # K,K,NTYPE
        self.train = True
        self._build()

    def _build(self):
        g, d = self.Pm.get, self.d
        g("E_skill", (K, d)); g("V", (K, d)); g("mu", (self.n_items, 1), "zeros")
        g("E_s", (P + 1, d), "normal", 0.1); g("E_sr", (2 * P, d), "normal", 0.1); g("E_r", (2, d), "normal", 0.1)
        g("start", (1, 1, d), "normal", 0.1)
        if self.cfg["graph"] != "none":
            for l in range(self.gl):
                g(f"g{l}_W", (d, d)); g(f"g{l}_Wl", (d, d)); g(f"g{l}_Wr", (d, d)); g(f"g{l}_Wv", (d, d))
                g(f"g{l}_a", (self.h, d // self.h, 1)); g(f"g{l}_tb", (NTYPE, self.h), "zeros")
                g(f"g{l}_ln_g", (d,), "ones"); g(f"g{l}_ln_b", (d,), "zeros")
                if self.cfg["strat_mod"]:
                    g(f"g{l}_Wgam", (d, d), scale=0.5); g(f"g{l}_Wbet", (d, d), scale=0.5)
                    g(f"g{l}_stb", (P + 1, NTYPE, self.h), "zeros")
        if self.cfg["encoder"] == "attn":
            for n in ["Wq", "Wk", "Wv", "Wo"]:
                g(n, (d, d))
            g("ln1_g", (d,), "ones"); g("ln1_b", (d,), "zeros"); g("ln2_g", (d,), "ones"); g("ln2_b", (d,), "zeros")
            g("F1", (d, 2 * d)); g("f1", (2 * d,), "zeros"); g("F2", (2 * d, d)); g("f2", (d,), "zeros")
            if self.cfg["decay"] != "none":
                g("theta", (self.h, 1, 1), 0.0)
            if self.cfg["relation"]:
                g("beta", (self.h, 1, 1), 1.0)
        else:
            for gate in "ifgo":
                g(f"Wx_{gate}", (d, d)); g(f"Wh_{gate}", (d, d)); g(f"b_{gate}", (d,), 1.0 if gate == "f" else "zeros")
        # heads
        g("K1", (2 * d, d)); g("k1", (d,), "zeros"); g("K2", (d, 1)); g("k2", (1,), "zeros")
        g("w_dt", (1, d), "normal", 0.1)
        # Strategy-Efficacy Head = baseline delayed-outcome model + centred strategy uplift
        g("B1", (2 * d, d)); g("b1", (d,), "zeros"); g("B2", (d, 1)); g("b2", (1,), "zeros")
        g("D1", (2 * d, d // 2)); g("dd1", (d // 2,), "zeros"); g("D2", (d // 2, 1))

    # ------------------------------------------------------------------ graph encoder
    def graph(self):
        """Returns Z (S,K,d) strategy-conditioned skill embeddings (S = P+1 or 1) and attention (S,h,K,K)."""
        p, d, h = self.Pm.p, self.d, self.h
        dh = d // h
        H = p["E_skill"]
        if self.cfg["graph"] == "none":
            return ag.reshape(H, (1, K, d)), None
        S = P + 1 if self.cfg["strat_mod"] else 1
        H = ag.reshape(H, (1, K, d))
        att = None
        for l in range(self.gl):
            Hs = H @ p[f"g{l}_W"]                                                  # S',K,d
            if self.cfg["strat_mod"]:
                es = ag.reshape(p["E_s"], (P + 1, 1, d))
                gam = ag.tanh(es @ p[f"g{l}_Wgam"]) * 0.5
                bet = es @ p[f"g{l}_Wbet"]
                Hs = Hs * (gam + 1.0) + bet                                        # FiLM -> S,K,d
            Lq = ag.reshape(Hs @ p[f"g{l}_Wl"], (S, K, 1, h, dh))
            Rk = ag.reshape(Hs @ p[f"g{l}_Wr"], (S, 1, K, h, dh))
            E = ag.leaky_relu(Lq + Rk, 0.2)                                        # S,K,K,h,dh
            E = ag.transpose(E, (0, 3, 1, 2, 4))                                   # S,h,K,K,dh
            e = ag.reshape(E @ ag.reshape(p[f"g{l}_a"], (1, h, 1, dh, 1)), (S, h, K, K))
            tb = ag.transpose(ag.reshape(Tensor(self.onehot_type) @ p[f"g{l}_tb"], (1, K, K, h)), (0, 3, 1, 2))
            e = e + tb
            if self.cfg["strat_mod"]:
                stb = ag.reshape(p[f"g{l}_stb"], (S, 1, 1, NTYPE, h))
                st = ag.sum_(ag.reshape(Tensor(self.onehot_type), (1, K, K, NTYPE, 1)) * stb, 3)   # S,K,K,h
                e = e + ag.transpose(st, (0, 3, 1, 2))
            att = ag.softmax(e, -1, self.gmask[None, None])                         # S,h,K,K
            Vv = ag.transpose(ag.reshape(Hs @ p[f"g{l}_Wv"], (S, K, h, dh)), (0, 2, 1, 3))
            M = ag.reshape(ag.transpose(att @ Vv, (0, 2, 1, 3)), (S, K, d))
            H = ag.layernorm(ag.elu(M) + H, p[f"g{l}_ln_g"], p[f"g{l}_ln_b"])
        return H, att

    # ------------------------------------------------------------------ full forward
    def forward(self, b, all_strats=False):
        """all_strats=False: SEH logit only for the logged strategy (training);
        all_strats=True : SEH logits for every candidate strategy (B,T,P) (inference)."""
        p, d, h = self.Pm.p, self.d, self.h
        B, Tn = b["items"].shape
        Z, att = self.graph()
        S = Z.shape[0]
        Mn = Tensor(b["Mn"])
        s = b["s"]; r = b["r"].astype(int)
        if S > 1:
            C_all = ag.transpose(Tensor(b["Mn"][None]) @ ag.reshape(Z, (S, 1, K, d)), (1, 2, 0, 3))   # B,T,S,d
            OH = np.eye(S, dtype=np.float32)[s][..., None]                                           # B,T,S,1
            C_log = ag.sum_(C_all * OH, 2)
            C_neu = C_all[:, :, P]
        else:
            C_neu = Mn @ ag.reshape(Z, (K, d)); C_log = C_neu; C_all = None
        diff = ag.embed(p["mu"], b["items"]) * (Mn @ p["V"])                      # Rasch variation
        q0 = C_neu + diff
        x = C_log + diff + ag.embed(p["E_sr"], 2 * s + r) + ag.embed(p["E_r"], r)
        start = p["start"] * Tensor(np.ones((B, 1, 1), np.float32))
        Xs = ag.concat([start, x[:, :-1]], 1)                                      # B,T,d (shifted)
        if self.cfg["encoder"] == "attn":
            hdn, attn_w = self._attn(q0, Xs, b, att)
        else:
            hdn, attn_w = self._lstm(Xs), None
        es_log = ag.embed(p["E_s"], s)
        # strategy dropout in the response head -> the neutral slot learns a strategy-agnostic mastery estimate
        s_head = np.where(self.rng.random(s.shape) < 0.15, P, s) if self.train else s
        u = ag.concat([hdn, q0 + ag.embed(p["E_s"], s_head)], -1)
        kt = ag.reshape(ag.relu(u @ p["K1"] + p["k1"]) @ p["K2"] + p["k2"], (B, Tn))
        out = dict(kt=kt, graph_att=att, attn=attn_w, h=hdn)
        Zn = Z[P] if S > 1 else ag.reshape(Z, (K, d))
        # ---- Strategy-Efficacy Head (uplift decomposition) ----
        if S > 1:
            Ccf = C_all[:, :, :P]                                                   # B,T,P,d
        else:
            Ccf = ag.reshape(C_neu, (B, Tn, 1, d)) * Tensor(np.ones((1, 1, P, 1), np.float32))
        Vall = Ccf + ag.reshape(p["E_s"][:P], (1, 1, P, d)) + ag.reshape(diff, (B, Tn, 1, d))
        hb = ag.reshape(hdn, (B, Tn, 1, d))
        U = ag.concat([hb * Vall, Vall], -1)                                        # B,T,P,2d
        delta = ag.reshape(ag.relu(U @ p["D1"] + p["dd1"]) @ p["D2"], (B, Tn, P))
        delta = delta - ag.mean(delta, -1, keepdims=True)                           # centred uplift
        Mnx = Tensor(b["Mn_nx"])
        e_nx = Mnx @ Zn + ag.embed(p["mu"], b["nx"]) * (Mnx @ p["V"]) + Tensor(b["ndt"][..., None]) @ p["w_dt"]
        base = ag.reshape(ag.relu(ag.concat([hdn, e_nx], -1) @ p["B1"] + p["b1"]) @ p["B2"] + p["b2"], (B, Tn))
        if not all_strats:
            OHs = np.eye(P, dtype=np.float32)[s]
            out["seh_log"] = base + ag.sum_(delta * OHs, -1)
        else:
            out["seh_all"] = delta.data
            out["seh_base"] = base.data
            H = hdn.data
            Hb = np.broadcast_to(H[:, :, None], (B, Tn, P, d))
            Es = p["E_s"].data[:P][None, None]
            uk = np.concatenate([Hb, q0.data[:, :, None] + Es], -1)
            out["kt_all"] = (np.maximum(uk @ p["K1"].data + p["k1"].data, 0) @ p["K2"].data + p["k2"].data)[..., 0]
            un = np.concatenate([H, q0.data + p["E_s"].data[P]], -1)
            out["kt_neutral"] = (np.maximum(un @ p["K1"].data + p["k1"].data, 0) @ p["K2"].data + p["k2"].data)[..., 0]
        return out

    def _relation(self, att, b):
        """R[t,j] = m_t^T A m_{j-1}: graph relatedness of the skills of query t and key j."""
        A = ag.mean(att[P] if att.shape[0] > 1 else att[0], 0)                     # K,K (row-stochastic)
        Mn = b["Mn"]
        Mprev = np.concatenate([np.zeros_like(Mn[:, :1]), Mn[:, :-1]], 1)
        R = Tensor(Mn) @ A @ Tensor(np.transpose(Mprev, (0, 2, 1)))               # B,T,T
        return ag.reshape(R, (Mn.shape[0], 1, Mn.shape[1], Mn.shape[1]))

    def _attn(self, q0, Xs, b, att):
        p, d, h = self.Pm.p, self.d, self.h
        dh = d // h
        B, Tn = b["items"].shape
        split = lambda X: ag.transpose(ag.reshape(X, (B, Tn, h, dh)), (0, 2, 1, 3))
        Q, Kk, V = split(q0 @ p["Wq"]), split(Xs @ p["Wk"]), split(Xs @ p["Wv"])
        sc = (Q @ ag.transpose(Kk, (0, 1, 3, 2))) * (1.0 / np.sqrt(dh))           # B,h,T,T
        if self.cfg["decay"] == "elapsed":
            sc = sc - ag.softplus(p["theta"]) * Tensor(b["Dlog"])
        elif self.cfg["decay"] == "position":
            sc = sc - ag.softplus(p["theta"]) * Tensor(b["Plog"])
        if self.cfg["relation"] and att is not None:
            sc = sc + p["beta"] * self._relation(att, b)
        A = ag.softmax(sc, -1, b["mask_add"])
        O = ag.reshape(ag.transpose(A @ V, (0, 2, 1, 3)), (B, Tn, d)) @ p["Wo"]
        hdn = ag.layernorm(q0 + ag.dropout(O, self.dp, self.rng, self.train), p["ln1_g"], p["ln1_b"])
        F = ag.relu(hdn @ p["F1"] + p["f1"]) @ p["F2"] + p["f2"]
        hdn = ag.layernorm(hdn + ag.dropout(F, self.dp, self.rng, self.train), p["ln2_g"], p["ln2_b"])
        return hdn, A

    def _lstm(self, Xs):
        p, d = self.Pm.p, self.d
        B, Tn, _ = Xs.shape
        hcur = Tensor(np.zeros((B, d), np.float32)); c = Tensor(np.zeros((B, d), np.float32))
        outs = []
        for t in range(Tn):
            xt = Xs[:, t]
            gi = ag.sigmoid(xt @ p["Wx_i"] + hcur @ p["Wh_i"] + p["b_i"])
            gf = ag.sigmoid(xt @ p["Wx_f"] + hcur @ p["Wh_f"] + p["b_f"])
            gg = ag.tanh(xt @ p["Wx_g"] + hcur @ p["Wh_g"] + p["b_g"])
            go = ag.sigmoid(xt @ p["Wx_o"] + hcur @ p["Wh_o"] + p["b_o"])
            c = gf * c + gi * gg
            hcur = go * ag.tanh(c)
            outs.append(ag.reshape(hcur, (B, 1, d)))
        return ag.dropout(ag.concat(outs, 1), self.dp, self.rng, self.train)

    def loss(self, b, lam_g=0.5):
        out = self.forward(b)
        B, Tn = b["items"].shape
        bi, ti = np.meshgrid(np.arange(B), np.arange(Tn), indexing="ij")
        L_kt = ag.bce_logits(out["kt"], b["r"], b["m"])
        L = L_kt
        if lam_g > 0:
            L = L + lam_g * ag.bce_logits(out["seh_log"], b["yg"], b["mg"] * b["w"])
        return L, out
