"""Case study: step-by-step trajectory of one test learner under the Teacher rule and GUIDE-PATH."""
import os, json
import numpy as np
from dataset import Corpus, ROOT
from fast import WorldModel
from planning import Planner, Evaluator, Task
from run_guidance import load_model
from simulator import SKILL_CODES, STRAT_CODES

R = os.path.join(ROOT, "results")


def main():
    C = Corpus()
    ids = np.sort(np.random.default_rng(5).choice(C.split["test"], 150, replace=False))
    # "typical" learner: pre-test mastery closest to the median of the 150 evaluated test learners
    import pandas as pd
    df = pd.read_csv(os.path.join(R, "paths", "GUIDE-PATH_ZPD-LGWO.csv"))
    u = int(df.learner.values[np.argmin(np.abs(df.pre.values - np.median(df.pre.values)))])
    theta = np.array(json.load(open(os.path.join(R, "epsg_theta.json")))["theta"])
    lam = json.load(open(os.path.join(R, "path_lambda.json")))["best"]
    wm = WorldModel(load_model(C, "GUIDE", 0), C.Qn)
    task = Task(C, u)
    out = dict(learner=u, domain=int(task.domain), targets=[SKILL_CODES[k] for k in task.targets], runs={})
    for name, pol in [("Teacher rule", "rule"), ("GUIDE-PATH", "plan")]:
        ev = Evaluator(C, [u])
        trace = []
        orig = ev.sim.step

        def step(st, items, strats, dt, rng, rows=None):
            res = orig(st, items, strats, dt, rng, rows)
            trace.append(dict(item=int(items[0]), skill=SKILL_CODES[C.cur.primary[items[0]]],
                              strategy=STRAT_CODES[int(strats[0])], correct=int(res[0][0]), p=float(res[1][0]),
                              mastery=ev.sim.probe_mastery(st, task.targets)[0].tolist()))
            return res
        ev.sim.step = step
        pl = Planner(C, wm, theta, lam=dict(u=lam["u"], n=lam["n"]))
        rows, _ = ev.run(pol, wm=wm if pol == "plan" else None, planner=pl, opt="lgwo")
        out["runs"][name] = dict(summary=rows[0], trace=trace)
        print(name, rows[0])
    json.dump(out, open(os.path.join(R, "case_study.json"), "w"), indent=1)


if __name__ == "__main__":
    main()
