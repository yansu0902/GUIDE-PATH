"""PATH: Pedagogy-Aware Trajectory Hunter -- learning-path planning with ZPD-LGWO and counterfactual
evaluation of recommendation policies in the ground-truth simulator (closed-loop MPC, 2 x H steps)."""
import os, json, time, argparse
import numpy as np
from simulator import (Simulator, load_states, P, K, PREREQ, SKILL_DOMAIN, TIME_MULT, RULE_SETS,
                       BehaviourPolicy, sig)
from dataset import Corpus, ROOT
from fast import WorldModel
from guidance import fused_scores, zscore, DOMAIN_RULES
from optimizers import gwo, pso, ga, random_search

LAM = dict(m=1.0, u=0.01, n=0.05, z=0.3, t=0.002, band=(0.5, 0.8), target=0.65)


class Task:
    """Goal-oriented path task for one learner."""

    def __init__(self, C, u):
        self.u = u
        it, r = C.items[u], C.resp[u]
        dom = SKILL_DOMAIN[C.cur.primary[it]]
        acc = np.array([r[dom == d].mean() if (dom == d).any() else 0.0 for d in range(6)])
        self.domain = int(acc.argmin())
        self.targets = np.nonzero(SKILL_DOMAIN == self.domain)[0]
        pre = np.nonzero(PREREQ[:, self.targets].sum(1) > 0)[0]
        skills = np.union1d(self.targets, pre)
        pool = np.concatenate([C.cur.by_skill[k] for k in skills])
        self.pool = pool[np.lexsort((C.cur.b[pool], C.cur.primary[pool]))]
        self.prim = C.cur.primary[self.pool]
        self.groups = {k: np.nonzero(self.prim == k)[0] for k in np.unique(self.prim)}
        L = max(len(v) for v in self.groups.values())
        self.gmat = np.full((K, L), -1)
        for k, v in self.groups.items():
            self.gmat[k, :len(v)] = v


def item_domain(C, items):
    return SKILL_DOMAIN[C.cur.primary[items]]


def domain_prior(dom):
    out = np.zeros(dom.shape + (P,))
    for d_, ss in DOMAIN_RULES.items():
        sel = dom == d_
        for s_ in ss:
            out[sel, s_] = 1.0
    return out


def rep_from_last3(last3):
    same = (last3[:, 0] == last3[:, 1]) & (last3[:, 1] == last3[:, 2]) & (last3[:, 0] >= 0)
    return np.eye(P)[np.where(same, last3[:, 0], 0)] * same[:, None]


class Planner:
    def __init__(self, C, wm, theta, H=10, repair=True, seeded=True, lam=None):
        self.C, self.wm, self.theta, self.H = C, wm, np.asarray(theta, float), H
        self.repair, self.seeded = repair, seeded
        self.lam = dict(LAM, **(lam or {}))

    def fused(self, p_neu, items, last3, uplift):
        dom = domain_prior(item_domain(self.C, items))
        return zscore(fused_scores(self.theta, p_neu, dom, rep_from_last3(last3), uplift))

    def need_readiness(self, ctx1, task):
        """Graph-aware need x readiness score NR_k for every skill (deficit of targets that are learnable now,
        and of prerequisites that block weak targets)."""
        m = self.wm.probe(ctx1, np.arange(K))[0]
        pre_cnt = PREREQ.sum(0)
        ready = np.where(pre_cnt > 0, (m @ PREREQ) / np.maximum(pre_cnt, 1), 1.0)
        NR = np.zeros(K)
        NR[task.targets] = (1 - m[task.targets]) * ready[task.targets]
        for j in np.unique(task.prim):
            if j in task.targets:
                continue
            deps = [t for t in task.targets if PREREQ[j, t] > 0]
            if deps:
                NR[j] = 0.5 * (1 - m[j]) * np.mean([1 - ready[t] for t in deps])
        return NR

    def rollout(self, ctx1, task, X, M0, NR=None):
        """X (W, 2H) in [0,1] -> (-J, X_repaired)."""
        wm, C, lam, H = self.wm, self.C, self.lam, self.H
        W = len(X)
        X = X.copy()
        ctx = wm.tile(ctx1, W)
        ctx["clock"] = np.full(W, ctx1["clock"][0])
        n = len(task.pool)
        idx = np.minimum((X[:, 0::2] * n).astype(int), n - 1)
        S = np.minimum((X[:, 1::2] * P).astype(int), P - 1)
        Ju = np.zeros(W); pen = np.zeros(W); mins = np.zeros(W); Jn = np.zeros(W)
        cnt = np.zeros((W, K))
        NR = self.need_readiness(ctx1, task) if NR is None else NR
        lo, hi = lam["band"]
        for h in range(H):
            q = task.pool[idx[:, h]]
            if self.repair:
                gi = task.gmat[C.cur.primary[q]]                                  # W,L pool indices
                valid = gi >= 0
                cand = task.pool[np.where(valid, gi, 0)]
                pn = wm.query(ctx, cand, None, uplift=False)["p_neu"]
                cur = pn[np.arange(W), (gi == idx[:, h:h + 1]).argmax(1)]
                bad = (cur < lo) | (cur > hi)
                best = np.where(valid, np.abs(pn - lam["target"]), 9).argmin(1)
                newi = gi[np.arange(W), best]
                idx[bad, h] = newi[bad]
                X[bad, 2 * h] = (newi[bad] + 0.5) / n
                q = task.pool[idx[:, h]]
            o = wm.query(ctx, q[:, None], S[:, h:h + 1])
            p, pn, up = o["p"][:, 0], o["p_neu"][:, 0], o["uplift"][:, 0]
            F = self.fused(pn, q, ctx["last3"], up)
            Ju += F[np.arange(W), S[:, h]]
            pen += np.maximum(0, np.abs(pn - lam["target"]) - 0.15)
            mins += C.cur.tmin[q] * TIME_MULT[S[:, h]]
            sk = C.cur.primary[q]
            Jn += NR[sk] * 0.85 ** cnt[np.arange(W), sk]
            cnt[np.arange(W), sk] += 1
            wm.append(ctx, q, S[:, h], p)
        M1 = wm.probe(ctx, task.targets).mean(1)
        J = lam["m"] * (M1 - M0) + lam["u"] * Ju / H + lam["n"] * Jn / H - lam["z"] * pen / H - lam["t"] * mins / (H * 5)
        return -J, X

    def init_wolves(self, ctx1, task, k, rng):
        wm, n, H = self.wm, len(task.pool), self.H
        o = wm.query(ctx1, task.pool[None], np.zeros((1, n), int))
        pn, up = o["p_neu"][0], o["uplift"][0]
        F = self.fused(pn, task.pool, np.repeat(ctx1["last3"], n, 0), up)
        mast = wm.probe(ctx1, task.targets)[0]
        order = task.targets[np.argsort(mast)]
        X = np.zeros((k, 2 * H))
        for w in range(k):
            for h in range(H):
                sk = order[(h + w) % len(order)] if rng.random() < 0.8 else rng.choice(task.prim)
                g = task.groups.get(sk, task.groups[task.prim[0]])
                j = g[np.argmin(np.abs(pn[g] - 0.65) + 0.05 * rng.random(len(g)))]
                srt = np.argsort(-F[j])
                s = srt[0] if rng.random() < 0.7 else srt[rng.integers(1, 3)]
                X[w, 2 * h] = (j + rng.random()) / n
                X[w, 2 * h + 1] = (s + rng.random()) / P
        return np.clip(X, 0, 0.9999)

    def plan(self, ctx1, task, opt="lgwo", pop=16, max_fe=400, seed=0):
        M0 = self.wm.probe(ctx1, task.targets).mean(1)
        NR = self.need_readiness(ctx1, task)
        f = lambda X: self.rollout(ctx1, task, X, M0, NR)
        lb, ub = np.zeros(2 * self.H), np.full(2 * self.H, 0.9999)
        rng = np.random.default_rng(seed)
        init = self.init_wolves(ctx1, task, pop // 2, rng) if (self.seeded and opt == "lgwo") else None
        if opt == "lgwo":
            tr = gwo(f, lb, ub, pop=pop, max_fe=max_fe, seed=seed, variant="lgwo", init=init)
        elif opt == "gwo":
            tr = gwo(f, lb, ub, pop=pop, max_fe=max_fe, seed=seed, variant="gwo")
        elif opt == "pso":
            tr = pso(f, lb, ub, pop=pop, max_fe=max_fe, seed=seed)
        elif opt == "ga":
            tr = ga(f, lb, ub, pop=pop, max_fe=max_fe, seed=seed)
        else:
            tr = random_search(f, lb, ub, pop=pop, max_fe=max_fe, seed=seed)
        x = tr.xbest
        _, xr = self.rollout(ctx1, task, x[None], M0, NR)        # decode with repair
        x = xr[0]
        n = len(task.pool)
        items = task.pool[np.minimum((x[0::2] * n).astype(int), n - 1)]
        strats = np.minimum((x[1::2] * P).astype(int), P - 1)
        return items, strats, tr

    def greedy_step(self, ctx1, task):
        """One-step look-ahead: best strategy per item by fused score, then best item by J1."""
        wm, n = self.wm, len(task.pool)
        o = wm.query(ctx1, task.pool[None], np.zeros((1, n), int))
        pn, up = o["p_neu"][0], o["uplift"][0]
        F = self.fused(pn, task.pool, np.repeat(ctx1["last3"], n, 0), up)
        s = F.argmax(1)
        p = wm.query(ctx1, task.pool[None], s[None], uplift=False)["p"][0]
        ctx = wm.tile(ctx1, n); ctx["clock"] = np.full(n, ctx1["clock"][0])
        M0 = wm.probe(ctx1, task.targets).mean(1)
        wm.append(ctx, task.pool, s, p)
        dM = wm.probe(ctx, task.targets).mean(1) - M0
        lam = self.lam
        NR = self.need_readiness(ctx1, task)
        J = lam["m"] * dM + lam["u"] * F[np.arange(n), s] + lam["n"] * NR[task.prim] \
            - lam["z"] * np.maximum(0, np.abs(pn - lam["target"]) - 0.15) \
            - lam["t"] * C_tm(self.C, task.pool, s) / 5
        j = int(J.argmax())
        return task.pool[j], int(s[j])


def C_tm(C, items, s):
    return C.cur.tmin[items] * TIME_MULT[s]


# ------------------------------------------------------------------------------------------- evaluation
class Evaluator:
    def __init__(self, C, ids, gap_h=24.0, rounds=2, H=10):
        self.C, self.ids, self.gap, self.rounds, self.H = C, ids, gap_h, rounds, H
        self.sim = Simulator(C.cur)
        self.states = load_states(os.path.join(ROOT, "data", "ground_truth", "final_states.npz"), np.arange(C.N))

    def run(self, policy, wm=None, planner=None, opt=None, log_curves=False):
        C, sim = self.C, self.sim
        rows = []
        curves = []
        for u in self.ids:
            task = Task(C, u)
            st = self.states.copy([u])
            sim.forget(st, np.array([self.gap])); st.clock += self.gap
            pre = sim.probe_mastery(st, task.targets)[0].mean()
            rng = np.random.default_rng(100000 + int(u))
            prng = np.random.default_rng(7 + int(u))
            ctx = None
            if wm is not None:
                ctx = wm.tile(wm.context(C.items[u], C.strat[u], C.resp[u], C.time[u]), 1)
                ctx["clock"] = np.array([C.time[u, -1] + self.gap])
            beh = None
            if policy == "rule":
                beh = BehaviourPolicy(C.cur, 1, prng)
                for t in range(C.T):
                    beh.update(C.items[u, t:t + 1], C.resp[u, t:t + 1])
            n_opt = 0; mins = 0; zpd = 0; optimal = 0; strat_hist = []
            steps = self.rounds * self.H
            plan_items, plan_strats = [], []
            for t in range(steps):
                if policy == "random":
                    q = int(prng.choice(task.pool)); s = int(prng.integers(P))
                elif policy == "rule":
                    tg = task.targets
                    k = tg[np.argmin(beh.est[0, tg] + 1e-3 * prng.random(len(tg)))]
                    g = C.cur.by_skill[k]
                    ph = sig(1.7 * (beh.est[0, k] - C.cur.b[g]))
                    q = int(g[np.argmin(np.abs(ph - 0.7))])
                    m = sig(1.7 * (beh.est[0] * C.cur.Qn[q]).sum())
                    s = int(prng.choice(RULE_SETS[int(beh.band(np.array([m]))[0])]))
                elif policy == "greedy":
                    q, s = planner.greedy_step(ctx, task)
                else:   # planner
                    if t % self.H == 0:
                        its, sts, tr = planner.plan(ctx, task, opt=opt, seed=int(u) + t)
                        plan_items, plan_strats = list(its), list(sts)
                        if log_curves:
                            curves.append(tr.curve)
                    q, s = int(plan_items[t % self.H]), int(plan_strats[t % self.H])
                p0 = sim.p_correct_nosupport(st, np.array([q]))[0]
                G = sim.expected_gain(st, np.array([q]))[0]
                optimal += int(s == G.argmax())
                zpd += int(0.5 <= p0 <= 0.8)
                r, p, mn = sim.step(st, np.array([q]), np.array([s]), np.array([0.05]), rng)
                mins += mn[0]; strat_hist.append(s)
                if beh is not None:
                    beh.update(np.array([q]), r)
                if wm is not None:
                    wm.append(ctx, np.array([q]), np.array([s]), r.astype(float))
            post = sim.probe_mastery(st, task.targets)[0].mean()
            st7 = st.copy()
            sim.forget(st7, np.array([168.0]))
            post7 = sim.probe_mastery(st7, task.targets)[0].mean()
            rows.append(dict(learner=int(u), domain=task.domain, pre=float(pre), post=float(post), post7=float(post7),
                             Ep=float((post - pre) / (1 - pre)), Ep_ret=float((post7 - pre) / (1 - pre)),
                             minutes=float(mins), zpd=zpd / steps, strat_opt=optimal / steps,
                             n_distinct_strats=len(set(strat_hist)),
                             gain_per_hour=float((post - pre) / (mins / 60))))
        return rows, curves
