"""Fast NumPy inference ("world model") for trained networks, used for learning-path rollouts.

Interface (both attention and LSTM encoders):
    ctx = wm.context(learner_row_logs)            -> history memory
    ctx = wm.tile(ctx, W)                          -> W copies (one per candidate plan / wolf)
    out = wm.query(ctx, items(W,m), strats(W,m))   -> dict(p (W,m), p_neu (W,m), uplift (W,m,P))
    wm.append(ctx, items(W,), strats(W,), r(W,), minutes)   (r may be soft = expected response)
    wm.probe(ctx, skills)                          -> (W, len(skills)) strategy-neutral mastery estimates
"""
import numpy as np
from simulator import K, P


def _sp(x):
    return np.logaddexp(0, x)


def _ln(x, g, b):
    mu = x.mean(-1, keepdims=True); v = ((x - mu) ** 2).mean(-1, keepdims=True)
    return (x - mu) / np.sqrt(v + 1e-5) * g + b


def _sig(x):
    return 1 / (1 + np.exp(-x))


class WorldModel:
    def __init__(self, model, Qn):
        model.train = False
        self.m = model
        self.cfg = model.cfg
        self.p = {k: v.data.astype(np.float64) for k, v in model.Pm.p.items()}
        Z, att = model.graph()
        Z = Z.data.astype(np.float64)
        self.Z = Z if Z.shape[0] > 1 else np.repeat(Z, P + 1, 0)            # (P+1,K,d)
        self.A = None
        if self.cfg.get("relation") and att is not None:
            a = att.data
            self.A = (a[P] if a.shape[0] > 1 else a[0]).mean(0).astype(np.float64)
        self.Qn = Qn.astype(np.float64)
        self.d, self.h = model.d, model.h
        self.Eint = {}

    # ------------------------------------------------------------- embeddings
    def q0(self, items, Mn=None, diff=True):
        Mn = self.Qn[items] if Mn is None else Mn
        q = Mn @ self.Z[P]
        if diff:
            q = q + self.p["mu"][items] * (Mn @ self.p["V"])
        return q

    def xvec(self, items, s, r):
        p = self.p
        Mn = self.Qn[items]
        c = np.einsum("...k,...kd->...d", Mn, self.Z[s])
        diff = p["mu"][items] * (Mn @ p["V"])
        r = np.asarray(r, float)[..., None]
        e1 = p["E_sr"][2 * s + 1] + p["E_r"][1]; e0 = p["E_sr"][2 * s] + p["E_r"][0]
        return c + diff + r * e1 + (1 - r) * e0

    # ------------------------------------------------------------- context
    def context(self, items, strats, resp, times):
        """Build memory from a logged history (1-D arrays)."""
        ctx = dict(n=len(items), clock=float(times[-1]))
        if self.cfg["encoder"] == "attn":
            X = self.xvec(items, strats, resp)
            ctx["X"] = np.concatenate([self.p["start"][0], X], 0)[None]        # 1,n+1,d
            ctx["t"] = np.concatenate([[0.0], times])[None]
            ctx["M"] = np.concatenate([np.zeros((1, K)), self.Qn[items]], 0)[None]
        else:
            X = self.xvec(items, strats, resp)
            hcur = np.zeros(self.d); c = np.zeros(self.d)
            hcur, c = self._lstm_step(self.p["start"][0, 0][None], hcur[None], c[None])
            for x in X:
                hcur, c = self._lstm_step(x[None], hcur, c)
            ctx["hc"] = (hcur, c)
        ctx["last3"] = np.array([list(strats[-1:-4:-1]) + [-1] * (3 - min(3, len(strats)))])
        ctx["prev_s"] = ctx["last3"]
        return ctx

    def tile(self, ctx, W):
        out = dict(n=ctx["n"], clock=np.full(W, ctx["clock"]), last3=np.repeat(ctx["last3"], W, 0))
        if "X" in ctx:
            out["X"] = np.repeat(ctx["X"], W, 0); out["t"] = np.repeat(ctx["t"], W, 0)
            out["M"] = np.repeat(ctx["M"], W, 0)
        else:
            out["hc"] = (np.repeat(ctx["hc"][0], W, 0), np.repeat(ctx["hc"][1], W, 0))
        return out

    # ------------------------------------------------------------- encoders
    def _lstm_step(self, x, hcur, c):
        p = self.p
        gi = _sig(x @ p["Wx_i"] + hcur @ p["Wh_i"] + p["b_i"])
        gf = _sig(x @ p["Wx_f"] + hcur @ p["Wh_f"] + p["b_f"])
        gg = np.tanh(x @ p["Wx_g"] + hcur @ p["Wh_g"] + p["b_g"])
        go = _sig(x @ p["Wx_o"] + hcur @ p["Wh_o"] + p["b_o"])
        c = gf * c + gi * gg
        return go * np.tanh(c), c

    def _state(self, ctx, Qe, Mq, tq):
        """Qe (W,m,d) query embeddings -> hidden (W,m,d)."""
        p = self.p
        W, m, d = Qe.shape
        if self.cfg["encoder"] != "attn":
            return np.repeat(ctx["hc"][0][:, None], m, 1)
        h, dh = self.h, d // self.h
        X, tm, Mm = ctx["X"], ctx["t"], ctx["M"]
        n = X.shape[1]
        Q = (Qe @ p["Wq"]).reshape(W, m, h, dh).transpose(0, 2, 1, 3)
        Kk = (X @ p["Wk"]).reshape(W, n, h, dh).transpose(0, 2, 1, 3)
        V = (X @ p["Wv"]).reshape(W, n, h, dh).transpose(0, 2, 1, 3)
        sc = Q @ Kk.transpose(0, 1, 3, 2) / np.sqrt(dh)                      # W,h,m,n
        if self.cfg["decay"] == "elapsed":
            D = np.log1p(np.maximum(tq[:, :, None] - tm[:, None, :], 0))      # W,m,n
            D[:, :, 0] = 0
            sc = sc - _sp(p["theta"])[None] * D[:, None]
        elif self.cfg["decay"] == "position":
            pos_q = n - 1                                                      # query index = number of past interactions
            dist = pos_q - (np.arange(n) - 1)
            Pl = np.log1p(dist.astype(float)); Pl[0] = 0
            sc = sc - _sp(p["theta"])[None] * Pl[None, None, None]
        if self.A is not None:
            R = Mq @ self.A @ Mm.transpose(0, 2, 1)                            # W,m,n
            sc = sc + p["beta"][None] * R[:, None]
        sc = sc - sc.max(-1, keepdims=True)
        a = np.exp(sc); a /= a.sum(-1, keepdims=True)
        O = (a @ V).transpose(0, 2, 1, 3).reshape(W, m, d) @ p["Wo"]
        hd = _ln(Qe + O, p["ln1_g"], p["ln1_b"])
        F = np.maximum(hd @ p["F1"] + p["f1"], 0) @ p["F2"] + p["f2"]
        return _ln(hd + F, p["ln2_g"], p["ln2_b"])

    def _kt(self, H, Qe, s):
        p = self.p
        u = np.concatenate([H, Qe + p["E_s"][s]], -1)
        return (np.maximum(u @ p["K1"] + p["k1"], 0) @ p["K2"] + p["k2"])[..., 0]

    def _uplift(self, H, items):
        p = self.p
        Mn = self.Qn[items]                                                    # W,m,K
        diff = p["mu"][items] * (Mn @ p["V"])                                  # W,m,d
        C = np.einsum("wmk,pkd->wmpd", Mn, self.Z[:P])                          # W,m,P,d
        Vall = C + p["E_s"][:P][None, None] + diff[:, :, None]
        U = np.concatenate([H[:, :, None] * Vall, Vall], -1)
        dl = (np.maximum(U @ p["D1"] + p["dd1"], 0) @ p["D2"])[..., 0]
        return dl - dl.mean(-1, keepdims=True)

    # ------------------------------------------------------------- public API
    def query(self, ctx, items, strats=None, uplift=True):
        W, m = items.shape
        Qe = self.q0(items)
        tq = np.repeat((ctx["clock"] + 0.05)[:, None], m, 1)
        H = self._state(ctx, Qe, self.Qn[items], tq)
        out = dict(p_neu=_sig(self._kt(H, Qe, np.full_like(items, P))))
        if strats is not None:
            out["p"] = _sig(self._kt(H, Qe, strats))
        if uplift:
            out["uplift"] = self._uplift(H, items)
        return out

    def probe(self, ctx, skills):
        W = ctx["clock"].shape[0]
        Mq = np.zeros((W, len(skills), K)); Mq[:, np.arange(len(skills)), skills] = 1
        Qe = Mq @ self.Z[P]
        tq = np.repeat((ctx["clock"] + 0.05)[:, None], len(skills), 1)
        H = self._state(ctx, Qe, Mq, tq)
        return _sig(self._kt(H, Qe, np.full((W, len(skills)), P)))

    def append(self, ctx, items, strats, r, dt=0.05):
        ctx["clock"] = ctx["clock"] + dt
        x = self.xvec(items, strats, r)                                        # W,d
        if "X" in ctx:
            ctx["X"] = np.concatenate([ctx["X"], x[:, None]], 1)
            ctx["t"] = np.concatenate([ctx["t"], ctx["clock"][:, None]], 1)
            ctx["M"] = np.concatenate([ctx["M"], self.Qn[items][:, None]], 1)
        else:
            ctx["hc"] = self._lstm_step(x, *ctx["hc"])
        ctx["last3"] = np.concatenate([strats[:, None], ctx["last3"][:, :2]], 1)
        ctx["n"] += 1
        return ctx

    def copy(self, ctx):
        out = {}
        for k, v in ctx.items():
            if isinstance(v, np.ndarray):
                out[k] = v.copy()
            elif isinstance(v, tuple):
                out[k] = tuple(x.copy() for x in v)
            else:
                out[k] = v
        return out
