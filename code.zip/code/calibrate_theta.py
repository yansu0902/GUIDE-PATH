"""Calibrate EPSG fusion weights for GUIDE seed 0 on validation logs (LGWO + SNIPS)."""
import os, json
import numpy as np
from dataset import Corpus, ROOT
from train_kt import predict
from guidance import Calibrator
from run_guidance import load_model, calibrate

C = Corpus()
m = load_model(C, "GUIDE", 0)
pv = predict(m, C, C.split["valid"], all_strats=True)
cal = Calibrator(C, C.split["valid"], pv)
th, v, curve = calibrate(cal, "LGWO", seed=0)
json.dump(dict(theta=th.tolist(), val_value=v, curve=curve), open(os.path.join(ROOT, "results", "epsg_theta.json"), "w"), indent=1)
print("theta", np.round(th, 3), "SNIPS", v)
