"""Confirmatory evaluation on all 600 test learners: summary + paired Wilcoxon tests."""
import os, glob, json
import numpy as np
import pandas as pd
from scipy.stats import wilcoxon
from dataset import ROOT

R = os.path.join(ROOT, "results")


def main():
    P = {}
    for f in glob.glob(os.path.join(R, "paths", "*_n600.csv")):
        df = pd.read_csv(f).sort_values("learner"); P[df.policy.iloc[0]] = df
    rows = []
    rng = np.random.default_rng(0)
    for name, df in P.items():
        r = dict(policy=name, n=len(df), **{m: float(df[m].mean()) for m in ["Ep", "Ep_ret", "zpd", "strat_opt", "minutes", "gain_per_hour"]})
        for refname in ["GUIDE-PATH (ZPD-LGWO)", "H=5"]:
            if refname in P and name != refname:
                ref = P[refname]
                for m in ["Ep", "Ep_ret"]:
                    d = ref[m].values - df[m].values
                    bs = [rng.choice(d, len(d)).mean() for _ in range(2000)]
                    r[f"{refname}|diff_{m}"] = float(d.mean())
                    r[f"{refname}|p_{m}"] = float(wilcoxon(ref[m].values, df[m].values).pvalue)
                    r[f"{refname}|ci_{m}"] = [float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))]
        rows.append(r)
    json.dump(rows, open(os.path.join(R, "path_summary_n600.json"), "w"), indent=1)
    for r in sorted(rows, key=lambda x: -x["Ep"]):
        print(json.dumps(r))


if __name__ == "__main__":
    main()
